#!/usr/bin/env python3
"""Regenerate the main manuscript figure data and PNG figures in one command.

The workflow is intentionally split into two steps:

1. ``scripts/generate_data.py`` solves ODE/SDE systems and writes result data.
2. ``scripts/plot_figures.py`` reads those saved data files and writes PNG figures.
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SCRIPT_DIR = ROOT / "scripts"


def run_script(script_name: str, extra_args: list[str] | None = None) -> None:
    script_path = SCRIPT_DIR / script_name
    env = os.environ.copy()
    env.setdefault("MPLCONFIGDIR", "/tmp/mpl")
    print(f"[figures] running {script_name}", flush=True)
    subprocess.run(
        [sys.executable, str(script_path), *(extra_args or [])],
        cwd=str(SCRIPT_DIR),
        env=env,
        check=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true", help="regenerate existing data files")
    parser.add_argument(
        "--figures",
        nargs="*",
        choices=[str(i) for i in range(1, 9)],
        default=[str(i) for i in range(1, 9)],
        help="figure numbers to regenerate; default regenerates all main figures",
    )
    parser.add_argument("--data-only", action="store_true", help="generate data but do not plot")
    parser.add_argument("--plot-only", action="store_true", help="plot from existing data without regenerating data")
    parser.add_argument(
        "--stochastic-replicates",
        type=int,
        default=1000,
        help="independent trajectories for stochastic cascade spectra and variance estimates",
    )
    parser.add_argument(
        "--stochastic-workers",
        type=int,
        default=60,
        help="worker processes for stochastic cascade replicate simulations",
    )
    args = parser.parse_args()

    figures = [str(fig) for fig in args.figures]
    if args.data_only and args.plot_only:
        raise SystemExit("--data-only and --plot-only cannot be used together")

    if not args.plot_only:
        data_args = ["--figures", *figures, "--stochastic-replicates", str(args.stochastic_replicates), "--stochastic-workers", str(args.stochastic_workers)]
        if args.force:
            data_args.append("--force")
        run_script("generate_data.py", data_args)

    if not args.data_only:
        run_script("plot_figures.py", ["--figures", *figures])

    print("[figures] complete", flush=True)


if __name__ == "__main__":
    main()
