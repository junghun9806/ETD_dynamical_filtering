# README

This directory contains the code used to regenerate the numerical data and PNG
figures.

## Note on figure formatting

The scripts reproduce the numerical content and panel structure of the
manuscript figures. Minor differences in text placement, label spacing,
annotation position, or final alignment can occur because the submitted
manuscript figures received manual final-touch formatting after numerical
generation. If exact publication formatting is required, use the generated PNG
files (or change format to the SVG for vector image) as reproducible 
numerical bases and apply final graphical adjustment in a vector or image editor.

The pipeline is intentionally split into two stages:

1. `scripts/generate_data.py` solves the ODE/SDE systems and writes `.npz`
   result files to `data/`.
2. `scripts/plot_figures.py` reads the saved `.npz` files and generates PNG
   figures to `figures/`.

## Requirements
The code requires NumPy (version 1.21 or higher), SciPy (version 1.8 or higher), and Matplotlib (version 3.5 or higher).

Run the commands below from this `Code_Submission/` directory.

## To generate all main figures
```bash
python3 run_all.py
```

## To regenerate all numerical data
```bash
python3 run_all.py --force
```

## To generate selected figures

```bash
python3 run_all.py --figures 1 2 6
```

## To generate data only

```bash
python3 run_all.py --data-only --force
```

## Generate figures from existing data
```bash
python3 run_all.py --plot-only
```

## The output figure names match the manuscript order:

| Manuscript figure | Data file | PNG output |
| --- | --- | --- |
| Fig. 1 | `data/Figure1.npz` | `figures/Figure1.png` |
| Fig. 2 | `data/Figure2.npz` | `figures/Figure2.png` |
| Fig. 3 | `data/Figure3.npz` | `figures/Figure3.png` |
| Fig. 4 | `data/Figure4.npz` | `figures/Figure4.png` |
| Fig. 5 | `data/Figure5.npz` | `figures/Figure5.png` |
| Fig. 6 | `data/Figure6.npz` | `figures/Figure6.png` |
| Fig. 7 | `data/Figure7.npz` | `figures/Figure7.png` |
| Fig. 8 | `data/Figure8.npz` | `figures/Figure8.png` |

## For the stochastic cascade figure, the default uses 1000 replicate trajectories. For quick regeneration the number of replicates can be changed.

```bash
python3 run_all.py --figures 6 --force \
  --stochastic-replicates <number-of-replicates> --stochastic-workers 64
```

## Contact

For questions, please email wjdgnswkd612@gmail.com.
