#!/usr/bin/env python3
"""Plot the main manuscript figures from saved ODE data."""

import argparse
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.lines import Line2D
from matplotlib.colors import LogNorm, TwoSlopeNorm
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import numpy as np

from figure_style import PALETTE, apply_style, finish_axes, style_axes, style_colorbar


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "figures"


def ensure_dirs() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)


def load(name: str):
    path = DATA_DIR / name
    if not path.exists():
        raise FileNotFoundError(f"missing figure data: {path}")
    return np.load(path)


def save(fig, name: str) -> None:
    fig.savefig(OUT_DIR / f"{name}.png", dpi=600)
    plt.close(fig)


def homogeneous_cutoff(n_step: np.ndarray, beta: float = 1.0) -> np.ndarray:
    n_step = np.asarray(n_step, dtype=float)
    return beta * np.sqrt(np.power(2.0, 1.0 / n_step) - 1.0)


def variance_after_m_filters(m_filter: np.ndarray, beta: float = 1.0, noise_strength: float = 1.0) -> np.ndarray:
    m_filter = np.asarray(m_filter, dtype=float)
    log_coeff = [
        math.lgamma(float(m) - 0.5) - 0.5 * math.log(math.pi) - math.lgamma(float(m))
        for m in m_filter.ravel()
    ]
    coeff = np.exp(np.asarray(log_coeff, dtype=float)).reshape(m_filter.shape)
    return noise_strength * coeff / beta


def all_step_variance(n_step: np.ndarray, beta: float = 1.0, noise_strength: float = 1.0) -> np.ndarray:
    values = []
    for n in np.asarray(n_step, dtype=int):
        m = np.arange(1, n + 1, dtype=float)
        values.append(float(np.sum(variance_after_m_filters(m, beta=beta, noise_strength=noise_strength))))
    return np.asarray(values, dtype=float)


def total_variance_with_internal_noise(n_step: np.ndarray, q_internal: np.ndarray, beta: float = 1.0) -> np.ndarray:
    n_step = np.asarray(n_step, dtype=int)
    q_internal = np.asarray(q_internal, dtype=float)
    out = np.empty((len(q_internal), len(n_step)), dtype=float)
    for j, q in enumerate(q_internal):
        for i, n in enumerate(n_step):
            upstream = float(variance_after_m_filters(np.asarray([n]), beta=beta, noise_strength=1.0)[0])
            if n > 1:
                internal_m = np.arange(1, n, dtype=float)
                internal = float(np.sum(variance_after_m_filters(internal_m, beta=beta, noise_strength=q)))
            else:
                internal = 0.0
            out[j, i] = upstream + internal
    return out


def plot_figure1() -> None:
    data = load("Figure1.npz")
    fig = plt.figure(figsize=(7.2, 9.2), constrained_layout=True)
    gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 1.25, 1.25])
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    ax_c = fig.add_subplot(gs[1, :])
    ax_d = fig.add_subplot(gs[2, :])

    t = data["step_t"]
    y = data["step_y"]
    tau_idx = int(np.argmin(np.abs(y - (1.0 + math.exp(-1.0)))))
    tau_t = float(t[tau_idx])
    ax_a.plot(t, y, color="black", lw=2.6)
    ax_a.axvline(0.0, color="red", ls="--", lw=1.5)
    ax_a.axvline(tau_t, color="red", ls="--", lw=1.5)
    ax_a.axhline(1.0, color="0.55", ls="--", lw=1.4)
    ax_a.axhline(1.0 + math.exp(-1.0), color="0.55", ls="--", lw=1.4)
    ax_a.annotate("", xy=(tau_t, 1.8), xytext=(0.0, 1.8), arrowprops=dict(arrowstyle="<->", color="red", lw=1.8))
    ax_a.text(tau_t + 0.08, 1.78, r"$\tau_r$", color="red", fontsize=13)
    ax_a.text(3.8, 0.68, "1/e\nadaptation", ha="center", va="center", fontsize=10, fontweight="bold")
    ax_a.set_xlabel("Time")
    ax_a.set_ylabel("Concentration")
    ax_a.set_xticks([])
    ax_a.set_yticks([])

    order = np.argsort(data["gain_omega"])
    ax_b.plot(data["gain_omega"][order], data["gain_value"][order], color=PALETTE["blue"], lw=2.4)
    ax_b.set_xlabel(r"Perturbation frequency ($\omega$)")
    ax_b.set_ylabel("Normalized response gain")
    ax_b.set_ylim(0, 1.05)

    for ax, prefix, title, omega in (
        (ax_c, "slow", "slow input", 0.15),
        (ax_d, "fast", "fast input", 1.5),
    ):
        t_trace = data[f"{prefix}_t"]
        input_signal = data[f"{prefix}_input"]
        output = data[f"{prefix}_output"]
        output_mean = float(np.mean(output))
        output_amp = 0.5 * float(np.max(output) - np.min(output))
        ax.axhspan(output_mean - output_amp, output_mean + output_amp, color="0.88", alpha=0.75, zorder=0)
        ax.annotate(
            "",
            xy=(38.2, output_mean + output_amp),
            xytext=(38.2, output_mean),
            arrowprops=dict(arrowstyle="<->", color="0.25", lw=1.4),
        )
        ax.text(38.55, output_mean + 0.5 * output_amp, "response\namplitude", color="0.25", fontsize=9, va="center")
        ax.plot(t_trace, input_signal, color="blue", lw=2.4)
        ax.plot(t_trace, output, color="black", lw=2.4)
        ax.axhline(2.0, color="0.75", ls="--", lw=1.5)
        ax.text(1.2, 3.05, fr"{title}: $\omega={omega:g}$, $\tau_r=3$", fontsize=14)
        ax.set_xlim(0, 40)
        ax.set_ylim(0, 3.5)
        ax.set_xlabel("Time")
        ax.set_ylabel("Concentration")

    finish_axes([ax_a, ax_b, ax_c, ax_d], labels=["(a)", "(b)", "(c)", "(d)"])
    save(fig, "Figure1")


def plot_figure2() -> None:
    data = load("Figure2.npz")
    fig, axes = plt.subplots(2, 2, figsize=(3.45, 3.55), constrained_layout=True)
    axes = axes.ravel()

    ax = axes[0]
    td = data["tau"]
    rt = data["relaxation_time"]
    amp_fraction = data["amp_fraction"]
    lim = [min(td.min(), rt.min()), max(td.max(), rt.max())]
    ax.loglog(lim, lim, color="black", lw=1.8, zorder=1)
    sc = ax.scatter(td, rt, c=amp_fraction, s=5, cmap="magma", vmin=0.0, vmax=0.5, alpha=0.18, linewidths=0, zorder=3)
    ax.set_xlabel(r"$\tau_{\rm ETD}$ (h)")
    ax.set_ylabel("Measured relaxation (h)")
    cbar = fig.colorbar(sc, ax=ax, label="Forcing fraction")
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 8

    ax = axes[1]
    omega_fixed = float(data["omega_fixed"][0])
    gain_fixed = data["fixed_gain"]
    valid_fixed = np.isfinite(gain_fixed) & (gain_fixed > 0)
    ax.scatter(
        data["fixed_tau"][valid_fixed],
        gain_fixed[valid_fixed],
        color="0.35",
        s=5,
        alpha=0.18,
        linewidths=0,
        zorder=3,
    )
    ax.set_xscale("log")
    tau_line = np.logspace(np.log10(data["fixed_tau"].min()), np.log10(data["fixed_tau"].max()), 300)
    ax.semilogx(tau_line, 1.0 / np.sqrt(1.0 + (omega_fixed * tau_line) ** 2), color="black", lw=2.2, zorder=1)
    ax.set_xlabel(r"$\tau_{\rm ETD}$ (h)")
    ax.set_ylabel(r"$G_\eta$")
    ax.set_ylim(0, 1.02)
    ax.text(0.06, 0.12, fr"$\omega={omega_fixed:g}$ h$^{{-1}}$", transform=ax.transAxes)

    scatter_y = data["collapse_gain"]
    omega_tau = data["collapse_omega_tau"]
    valid = np.isfinite(scatter_y) & (scatter_y > 0) & np.isfinite(omega_tau) & (omega_tau > 0)

    ax = axes[2]
    sc = ax.scatter(
        data["tau"][valid],
        scatter_y[valid],
        c=omega_tau[valid],
        s=5,
        cmap="viridis",
        norm=LogNorm(vmin=float(np.nanmin(omega_tau[valid])), vmax=float(np.nanmax(omega_tau[valid]))),
        alpha=0.25,
        linewidths=0,
        zorder=3,
    )
    ax.set_xscale("log")
    ax.set_xlabel(r"$\tau_{\rm ETD}$ (h)")
    ax.set_ylabel(r"$G_\eta$")
    ax.set_ylim(0, 1.02)
    cbar = fig.colorbar(sc, ax=ax, label=r"$\omega\tau_{\rm ETD}$")
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 8

    ax = axes[3]
    local_x = data["local_line_x"]
    local_gain = data["local_line_gain"]
    ax.semilogx(local_x, local_gain, color="black", lw=2.2, zorder=1)
    ax.scatter(data["collapse_omega_tau"][valid], scatter_y[valid], color="0.35", s=5, alpha=0.18, linewidths=0, zorder=3)
    ax.set_xlabel(r"$\omega\tau_{\rm ETD}$")
    ax.set_ylabel(r"$G_\eta$")
    ax.set_ylim(0, 1.02)

    axes[0].set_xlabel(r"$\tau_{\rm ETD}$ (h)")
    finish_axes(axes, labels=["(a)", "(b)", "(c)", "(d)"])
    save(fig, "Figure2")


def plot_figure3() -> None:
    data = load("Figure3.npz")
    fig, axes = plt.subplots(3, 2, figsize=(3.45, 4.55), constrained_layout=True)
    colors = {"mRNA": PALETTE["orange"], "Protein": PALETTE["blue"]}

    omega = data["panel_a_omega"]
    axes[0, 0].semilogx(omega, data["panel_a_m_gain"], color=colors["mRNA"], label="mRNA")
    axes[0, 0].semilogx(omega, data["panel_a_p_gain"], color=colors["Protein"], label="Protein")
    axes[0, 0].scatter(omega[::4], data["panel_a_m_gain"][::4], color=colors["mRNA"], s=10)
    axes[0, 0].scatter(omega[::4], data["panel_a_p_gain"][::4], color=colors["Protein"], s=10)
    axes[0, 0].set_xlabel(r"$\omega/\beta$")
    axes[0, 0].set_ylabel(r"$G_\eta$")
    axes[0, 0].legend(frameon=False)

    x = data["panel_b_x"]
    axes[0, 1].semilogx(x, data["panel_b_m_gain"], color=colors["mRNA"], label=r"mRNA: $\omega/\beta_m$")
    axes[0, 1].semilogx(x, data["panel_b_p_gain"], color=colors["Protein"], label=r"Protein: $\omega\tau_{\rm ETD}$")
    axes[0, 1].scatter(x[::4], data["panel_b_m_gain"][::4], color=colors["mRNA"], s=10)
    axes[0, 1].scatter(x[::4], data["panel_b_p_gain"][::4], color=colors["Protein"], s=10)
    axes[0, 1].set_xlabel("Normalized frequency")
    axes[0, 1].set_ylabel(r"$G_\eta$")
    axes[0, 1].legend(frameon=False)

    rows = data["cascade_rows"]
    stage_colors = [PALETTE["blue"], "#d98c00", "#009e73", "#d55e00", "#cc79a7"]
    for n in range(6, 26):
        pts = rows[rows[:, 0] == n]
        axes[1, 0].semilogx(pts[:, 1], pts[:, 3], color="0.72", lw=0.55, zorder=1)
        axes[1, 1].loglog(pts[:, 1], pts[:, 3], color="0.72", lw=0.55, zorder=1)
    for n in range(1, 6):
        pts = rows[rows[:, 0] == n]
        color = stage_colors[n - 1]
        axes[1, 0].semilogx(pts[:, 1], pts[:, 3], color=color, lw=1.05, label=fr"$x_{n}$", zorder=3)
        axes[1, 1].loglog(pts[:, 1], pts[:, 3], color=color, lw=1.05, label=fr"$x_{n}$", zorder=3)
    axes[1, 0].set_xlabel(r"$\omega\tau_{\rm ETD}$")
    axes[1, 0].set_ylabel(r"$G_\eta$")
    axes[1, 1].set_xlabel(r"$\omega\tau_{\rm ETD}$")
    axes[1, 1].set_ylabel(r"$G_\eta$")
    axes[1, 0].set_xlim(1e-1, 1e2)
    axes[1, 1].set_xlim(1e-1, 1e2)
    axes[1, 1].set_ylim(1e-6, 1.0)
    axes[1, 0].legend(frameon=False)
    axes[1, 1].legend(frameon=False)

    delay = data["delay_rows"]
    depth_colors = [PALETTE["blue"], PALETTE["orange"], PALETTE["green"], PALETTE["purple"]]
    delay_styles = {
        1: (0, (1.0, 1.0)),
        2: (0, (2.0, 1.0)),
        4: (0, (3.0, 1.2, 1.0, 1.2)),
        8: "solid",
    }
    marker_offsets = {1: 0, 2: 2, 4: 4, 8: 6}
    for n, color in zip((1, 2, 4, 8), depth_colors):
        pts = delay[delay[:, 0] == n]
        line_style = delay_styles[n]
        marker_offset = marker_offsets[n]
        axes[2, 0].semilogx(pts[:, 1], pts[:, 2], color=color, lw=1.0, ls=line_style, label=f"n={n}")
        axes[2, 1].semilogx(pts[:, 1], pts[:, 3], color=color, lw=1.0, ls=line_style)
        axes[2, 0].scatter(pts[marker_offset::10, 1], pts[marker_offset::10, 2], s=9, facecolors="white", edgecolors=color, linewidths=0.75)
        axes[2, 1].scatter(pts[marker_offset::10, 1], pts[marker_offset::10, 3], s=9, facecolors="white", edgecolors=color, linewidths=0.75)
    axes[2, 0].set_xlabel(r"$\omega/\beta$")
    axes[2, 0].set_ylabel(r"$\tau_{\rm app}/\tau_0$")
    axes[2, 1].set_xlabel(r"$\omega/\beta$")
    axes[2, 1].set_ylabel(r"$\tau_{\rm g}/\tau_0$")
    axes[2, 0].legend(frameon=False)
    axes[2, 0].set_xlim(10**-1.2, 10**1.2)
    axes[2, 1].set_xlim(10**-1.2, 10**1.2)

    for ax in axes.ravel():
        ax.set_ylim(bottom=0 if ax is not axes[1, 1] else 1e-6, top=1.02)
    finish_axes(axes, labels=["(a)", "(b)", "(c)", "(d)", "(e)", "(f)"])
    save(fig, "Figure3")


def plot_figure4() -> None:
    data = load("Figure4.npz")
    fig, axes = plt.subplots(3, 1, figsize=(3.45, 4.0), constrained_layout=True)
    steady = data["steady_rows"]
    metric = data["metric_rows"]
    gain = data["gain_rows"]
    transfer = data["transfer_rows"] if "transfer_rows" in data.files else None

    theta = steady[:, 0]
    p_ss = steady[:, 2]
    loop = steady[:, 3]
    axes[0].plot(theta, p_ss, lw=2.2, color=PALETTE["blue"], label=r"$p_{ss}$")
    axes[0].plot(theta, loop / max(loop.max(), 1e-12), lw=2.2, color=PALETTE["red"], label=r"normalized $L_\theta$")
    axes[0].set_xlabel(r"feedback strength $\theta_p$")
    axes[0].set_ylabel("Relative value")
    axes[0].legend(frameon=False)

    colors = {0.0: PALETTE["blue"], 0.5: PALETTE["orange"], 1.0: PALETTE["green"], 5.0: PALETTE["purple"], 10.0: PALETTE["red"]}
    for theta_value, color in colors.items():
        if transfer is not None:
            pts_transfer = transfer[np.isclose(transfer[:, 0], theta_value)]
            axes[1].semilogx(pts_transfer[:, 1], pts_transfer[:, 2], color=color, lw=1.9, label=fr"$\theta={theta_value:g}$")
        else:
            pts = gain[np.isclose(gain[:, 0], theta_value)]
            axes[1].semilogx(pts[:, 1], pts[:, 2], color=color, lw=1.9, label=fr"$\theta={theta_value:g}$")
        pts_ode = gain[np.isclose(gain[:, 0], theta_value)]
        axes[1].scatter(pts_ode[::5, 1], pts_ode[::5, 2], s=13, facecolors="white", edgecolors=color, linewidths=1.0, zorder=3)
    axes[1].set_xlabel("Frequency")
    axes[1].set_ylabel("Normalized gain")
    axes[1].legend(frameon=False, fontsize=6)

    delay = metric[:, 3]
    cutoff = metric[:, 4]
    axes[2].plot(metric[:, 0], delay / delay[0], lw=2.2, color=PALETTE["blue"], label=r"low-frequency delay")
    axes[2].plot(metric[:, 0], cutoff / cutoff[0], lw=2.2, color=PALETTE["orange"], label=r"cutoff")
    axes[2].set_xlabel(r"feedback strength $\theta_p$")
    axes[2].set_ylabel("Relative value")
    axes[2].legend(frameon=False, loc="center right")
    finish_axes(axes, labels=["(a)", "(b)", "(c)"])
    save(fig, "Figure4")


def plot_figure5() -> None:
    data = load("Figure5.npz")
    fig, axes = plt.subplots(2, 2, figsize=(3.45, 3.20), constrained_layout=True)
    heat = data["heat_rows"]
    omega_vals = np.asarray(sorted(set(heat[:, 1])))
    n_vals = np.asarray(sorted(set(heat[:, 0]))).astype(int)
    z = np.array([[heat[(heat[:, 0] == n) & np.isclose(heat[:, 1], omega), 2][0] for omega in omega_vals] for n in n_vals])
    mesh = axes[0, 0].pcolormesh(
        omega_vals,
        n_vals,
        z,
        shading="auto",
        cmap="viridis",
        vmin=0,
        vmax=1,
        linewidth=0,
        edgecolors="none",
        antialiased=False,
        rasterized=True,
    )
    axes[0, 0].set_xscale("log")
    axes[0, 0].set_xlabel("Frequency")
    axes[0, 0].set_ylabel("Cascade depth")
    cbar = fig.colorbar(mesh, ax=axes[0, 0], label="Normalized gain")
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 16

    cutoff = data["cutoff_rows"]
    axes[0, 1].plot(cutoff[:, 0], cutoff[:, 1], "-", lw=1.1, color=PALETTE["blue"], label="measured cutoff")
    axes[0, 1].scatter(cutoff[:, 0], cutoff[:, 1], s=9, color=PALETTE["blue"], zorder=3)
    axes[0, 1].set_xlabel("Cascade depth")
    axes[0, 1].set_ylabel("Cutoff frequency")
    y_top = float(np.nanmax(cutoff[:, 1]))
    axes[0, 1].set_ylim(-0.05 * y_top, 1.05 * y_top)
    axes[0, 1].legend(frameon=False)

    hetero = data["hetero_rows"]
    sc = axes[1, 0].scatter(
        hetero[:, 0],
        hetero[:, 1],
        c=hetero[:, 2],
        s=5,
        cmap="magma",
        vmin=0.2,
        vmax=0.8,
        alpha=0.62,
        linewidths=0,
    )
    axes[1, 0].set_xscale("log")
    axes[1, 0].set_yscale("log")
    axes[1, 0].set_xlabel("Total delay")
    axes[1, 0].set_ylabel("Cutoff frequency")
    cbar = fig.colorbar(sc, ax=axes[1, 0], label="Dominant-step delay fraction")
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 16

    pulse = data["pulse_rows"]
    max_y = float(np.max(pulse[:, 2]))
    for n_step, color in zip((1, 2, 4, 8), (PALETTE["blue"], PALETTE["orange"], PALETTE["green"], PALETTE["purple"])):
        pts = pulse[pulse[:, 0] == n_step]
        axes[1, 1].plot(pts[:, 1], pts[:, 2] / max_y, color=color, label=f"n={n_step}")
    axes[1, 1].set_xlabel("Time")
    axes[1, 1].set_ylabel("Normalized output")
    axes[1, 1].legend(frameon=False)
    finish_axes(axes, labels=["(a)", "(b)", "(c)", "(d)"])
    save(fig, "Figure5")


def plot_figure7() -> None:
    data = load("Figure7.npz")
    n_step = data["n_step"]
    cutoff = data["cutoff"]
    delay = data["delay"]
    upstream_var = data["upstream_var"]
    all_step_var = data["all_step_var"]
    q_values = data["q_values"]
    log_ratio = data["log_ratio"]

    fig = plt.figure(figsize=(7.25, 2.25), constrained_layout=False)
    gs = fig.add_gridspec(
        1,
        3,
        width_ratios=[0.96, 0.96, 0.96],
        left=0.08,
        right=0.925,
        bottom=0.24,
        top=0.87,
        wspace=0.30,
    )
    axes = np.asarray([fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[0, 1]), fig.add_subplot(gs[0, 2])], dtype=object)

    axes[0].plot(n_step, delay, color=PALETTE["blue"], lw=1.4, label="mean delay")
    axes[0].set_xlabel("Cascade depth")
    axes[0].set_ylabel(r"Mean delay $n/\beta$", color=PALETTE["blue"])
    axes[0].tick_params(axis="y", colors=PALETTE["blue"])
    left_bottom = -0.05 * (float(delay.max()) - float(delay.min()))
    left_top = float(delay.max()) + 0.05 * (float(delay.max()) - float(delay.min()))
    axes[0].set_ylim(left_bottom, left_top)
    ax_cut = axes[0].twinx()
    ax_cut.plot(n_step, cutoff, color=PALETTE["red"], lw=1.4, label="cutoff")
    ax_cut.set_ylabel(r"$\omega_c/\beta$", color=PALETTE["red"], labelpad=0)
    zero_fraction = (0.0 - left_bottom) / (left_top - left_bottom)
    right_top = 1.05 * float(cutoff.max())
    right_bottom = -zero_fraction * right_top / (1.0 - zero_fraction)
    ax_cut.set_ylim(right_bottom, right_top)
    ax_cut.tick_params(axis="y", colors=PALETTE["red"], direction="in", width=0.6, length=2.5, labelsize=6)
    for spine in ax_cut.spines.values():
        spine.set_linewidth(0.6)

    axes[1].loglog(cutoff, upstream_var / cutoff, color=PALETTE["blue"], lw=1.2, label="upstream")
    axes[1].loglog(cutoff, all_step_var / cutoff, color=PALETTE["purple"], lw=1.2, label="all-step")
    for n in (1, 4, 16, 64):
        idx = int(n - 1)
        axes[1].scatter(
            cutoff[idx],
            upstream_var[idx] / cutoff[idx],
            s=14,
            facecolors=PALETTE["blue"],
            edgecolors=PALETTE["blue"],
            linewidths=0.7,
            zorder=3,
        )
        axes[1].scatter(cutoff[idx], all_step_var[idx] / cutoff[idx], s=11, color=PALETTE["purple"], zorder=3)
        axes[1].text(cutoff[idx] * 1.04, all_step_var[idx] / cutoff[idx] * 1.03, str(n), fontsize=6)
    axes[1].invert_xaxis()
    axes[1].set_xlabel(r"Cutoff $\omega_c/\beta$")
    axes[1].set_ylabel(r"Variance per bandwidth")
    axes[1].legend(frameon=False, fontsize=6, loc="lower left")

    mesh = axes[2].pcolormesh(
        n_step,
        q_values,
        log_ratio,
        shading="auto",
        cmap="coolwarm",
        norm=TwoSlopeNorm(vmin=-1.0, vcenter=0.0, vmax=1.0),
        linewidth=0,
        edgecolors="none",
        antialiased=False,
        rasterized=True,
    )
    axes[2].contour(n_step, q_values, log_ratio, levels=[0.0], colors="black", linewidths=1.0)
    axes[2].set_yscale("log")
    axes[2].set_xlabel("Cascade depth")
    axes[2].set_ylabel(r"Internal noise ratio $q$")
    axes[2].set_xlim(1, 64)
    cbar = fig.colorbar(mesh, ax=axes[2], label="Relative output variance", fraction=0.055, pad=0.020)
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.set_ticks([-1.0, 0.0, 1.0])
    cbar.set_ticklabels([r"$0.1$", r"$1$", r"$10$"])
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 8

    for ax in axes:
        ax.xaxis.labelpad = 2
        ax.yaxis.labelpad = 1
    finish_axes(axes, labels=["(a)", "(b)", "(c)"])
    save(fig, "Figure7")


def plot_stochastic_cascade() -> None:
    data = load("Figure6.npz")
    fig, axes = plt.subplots(3, 2, figsize=(3.45, 4.55), constrained_layout=False)
    fig.subplots_adjust(left=0.145, right=0.945, bottom=0.10, top=0.955, wspace=0.48, hspace=0.62)
    axes = axes.ravel()
    colors = {1: PALETTE["blue"], 3: PALETTE["orange"], 5: PALETTE["red"]}

    theory = data["spectrum_theory_rows"]
    sim = data["spectrum_sim_rows"]
    for source, color in colors.items():
        pts = theory[theory[:, 0] == source]
        pts = pts[(pts[:, 1] >= 1e-2) & (pts[:, 1] <= 10.0)]
        axes[0].loglog(pts[:, 1], pts[:, 2], color=color, lw=1.1, label=fr"Step {source}")
        pts_sim = sim[sim[:, 0] == source]
        pts_sim = pts_sim[(pts_sim[:, 1] >= 1e-2) & (pts_sim[:, 1] <= 10.0)]
        axes[0].scatter(pts_sim[::4, 1], pts_sim[::4, 2], s=9, facecolors="white", edgecolors=color, linewidths=0.65)
    axes[0].set_xlabel("Frequency")
    axes[0].set_ylabel("Normalized output spectrum")
    axes[0].set_xlim(1e-2, 10.0)
    axes[0].set_ylim(1e-10, 1.5)
    axes[0].legend(frameon=False, title="Noise source", fontsize=6, title_fontsize=6)

    variance = data["variance_rows"]
    theory_var = variance[:, 1]
    sim_var = variance[:, 2]
    sim_sem = variance[:, 3] if variance.shape[1] > 3 else np.zeros_like(sim_var)
    theory_fraction = theory_var / np.sum(theory_var)
    valid = np.isfinite(sim_var)
    axes[1].plot(
        variance[:, 0],
        theory_fraction,
        "-o",
        color="black",
        lw=1.0,
        ms=3.0,
        label="theory",
        zorder=2,
    )
    axes[1].errorbar(
        variance[valid, 0],
        sim_var[valid] / np.sum(theory_var),
        yerr=sim_sem[valid] / np.sum(theory_var),
        fmt="o",
        ms=3.6,
        color=PALETTE["red"],
        ecolor=PALETTE["red"],
        elinewidth=0.8,
        capsize=1.8,
        zorder=3,
        label="simulation",
    )
    axes[1].set_xlabel("Noise-source step")
    axes[1].set_ylabel("Output variance fraction")
    axes[1].set_xticks(variance[:, 0])
    axes[1].legend(frameon=False, fontsize=6)

    depth = data["depth_rows"]
    norm = max(depth[0, 1], 1e-14)
    depth_n = depth[:, 0]
    cutoff = np.sqrt(np.power(2.0, 1.0 / depth_n) - 1.0)
    all_var = depth[:, 3] / norm
    up_var = depth[:, 1] / norm
    axes[2].loglog(cutoff, all_var, color=PALETTE["purple"], marker="o", ms=2.6, lw=1.0, label="all-step")
    axes[2].loglog(cutoff, up_var, color=PALETTE["blue"], marker="o", ms=2.6, lw=1.0, label="upstream")
    for n, x, y in zip(depth_n.astype(int), cutoff, all_var):
        if n in (1, 4, 8, 10):
            axes[2].text(x * 1.04, y * 1.02, str(n), fontsize=7)
    axes[2].set_xlabel(r"Deterministic cutoff $\omega_c/\beta$")
    axes[2].set_ylabel("Normalized output variance")
    axes[2].set_xlim(1.05, 0.2)
    axes[2].set_xticks([1.0, 0.3, 0.2])
    axes[2].set_xticklabels(["1", "0.3", "0.2"])
    axes[2].xaxis.set_minor_formatter(mticker.NullFormatter())
    axes[2].set_ylim(min(np.min(up_var), np.min(all_var)) * 0.75, max(np.max(up_var), np.max(all_var)) * 1.35)
    axes[2].legend(frameon=False, fontsize=6)

    collapse = data["collapse_rows"]
    m_colors = {
        1: PALETTE["red"],
        2: PALETTE["orange"],
        3: PALETTE["green"],
        4: PALETTE["cyan"],
        5: PALETTE["blue"],
    }

    fixed_m = collapse[collapse[:, 0] == 5]
    sc = axes[3].scatter(
        fixed_m[:, 2],
        fixed_m[:, 5],
        c=fixed_m[:, 4],
        s=5,
        cmap="viridis",
        norm=LogNorm(vmin=float(np.nanmin(fixed_m[:, 4])), vmax=float(np.nanmax(fixed_m[:, 4]))),
        alpha=0.17,
        linewidths=0,
    )
    axes[3].set_xscale("log")
    axes[3].set_yscale("log")
    axes[3].set_ylim(1e-10, 1.0)
    axes[3].set_xlabel(r"$\tau_{\rm ETD}$")
    axes[3].set_ylabel("Normalized spectrum")
    cbar = fig.colorbar(sc, ax=axes[3], label=r"$\omega\tau_{\rm ETD}$", fraction=0.060, pad=0.050)
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.set_ticks([1e-2, 1e0, 1e2])
    cbar.set_ticklabels([r"$10^{-2}$", r"$10^0$", r"$10^2$"])
    cbar.ax.yaxis.set_ticks_position("right")
    cbar.ax.yaxis.set_label_position("right")
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 6
    cbar.ax.tick_params(pad=1.0)

    x_line = np.logspace(-2.0, 2.0, 260)
    axes[4].scatter(
        fixed_m[:, 4],
        fixed_m[:, 5],
        color="0.45",
        s=5,
        alpha=0.15,
        linewidths=0,
    )
    axes[4].loglog(x_line, (1.0 + x_line * x_line) ** (-5), color="black", lw=1.0)
    axes[4].set_xlabel(r"$\omega\tau_{\rm ETD}$")
    axes[4].set_ylabel("Normalized spectrum")
    axes[4].set_ylim(1e-10, 1.0)

    axins = inset_axes(axes[4], width="44%", height="38%", loc="lower left", borderpad=0.75)
    axins.scatter(
        fixed_m[:, 4],
        fixed_m[:, 5],
        color="0.45",
        s=3,
        alpha=0.14,
        linewidths=0,
    )
    axins.plot(x_line, (1.0 + x_line * x_line) ** (-5), color="black", lw=0.8)
    axins.set_xscale("log")
    axins.set_xlim(1e-2, 1e2)
    axins.set_ylim(0.0, 1.0)
    axins.set_xticks([1e-2, 1e2])
    axins.set_xticklabels([r"$10^{-2}$", r"$10^2$"])
    axins.set_yticks([0.0, 1.0])
    axins.tick_params(direction="in", width=0.5, length=2.0, labelsize=5, pad=1)
    for spine in axins.spines.values():
        spine.set_linewidth(0.55)
    axins.set_facecolor("white")

    for m_filter, color in m_colors.items():
        marker_x = np.logspace(-2.0, 2.0, 18)
        marker_y = (1.0 + marker_x * marker_x) ** (-m_filter)
        axes[5].scatter(marker_x, marker_y, s=9, facecolors="white", edgecolors=color, linewidths=0.65, alpha=0.75)
        axes[5].loglog(x_line, (1.0 + x_line * x_line) ** (-m_filter), color=color, lw=1.0, label=fr"$m={m_filter}$")
    axes[5].set_xlabel(r"$\omega\tau_{\rm ETD}$")
    axes[5].set_ylabel("Normalized spectrum")
    axes[5].set_ylim(1e-10, 1.5)
    axes[5].legend(frameon=False, fontsize=6, handlelength=1.4, loc="lower left")

    for ax in axes:
        ax.xaxis.labelpad = 2
        ax.yaxis.labelpad = 1

    finish_axes(axes, labels=["(a)", "(b)", "(c)", "(d)", "(e)", "(f)"])
    save(fig, "Figure6")


def plot_stochastic_collapse() -> None:
    data = load("Figure6.npz")
    fig, axes = plt.subplots(2, 1, figsize=(3.35, 4.85), constrained_layout=True)
    axes = np.asarray(axes, dtype=object).ravel()
    collapse = data["collapse_rows"]
    sim = data["collapse_sim_rows"]
    m_colors = {
        1: PALETTE["red"],
        2: PALETTE["orange"],
        3: PALETTE["green"],
        4: PALETTE["cyan"],
        5: PALETTE["blue"],
    }

    fixed_m = collapse[collapse[:, 0] == 5]
    sc = axes[0].scatter(
        fixed_m[:, 2],
        fixed_m[:, 5],
        c=fixed_m[:, 4],
        s=5,
        cmap="viridis",
        norm=LogNorm(vmin=float(np.nanmin(fixed_m[:, 4])), vmax=float(np.nanmax(fixed_m[:, 4]))),
        alpha=0.24,
        linewidths=0,
    )
    axes[0].set_xscale("log")
    axes[0].set_yscale("log")
    axes[0].set_ylim(1e-10, 1.5)
    axes[0].set_xlabel(r"$\tau_{\rm ETD}$", fontsize=10)
    axes[0].set_ylabel("Norm. spectrum", fontsize=10)
    cbar = fig.colorbar(sc, ax=axes[0], label=r"$\omega\tau_{\rm ETD}$", shrink=0.88)
    style_colorbar(cbar)
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 12
    cbar.ax.yaxis.label.set_size(9)
    cbar.ax.tick_params(labelsize=8)

    x_line = np.logspace(-2.0, 2.0, 260)
    for m_filter, color in m_colors.items():
        pts = sim[sim[:, 0] == m_filter]
        axes[1].scatter(pts[::3, 4], pts[::3, 5], s=13, facecolors="white", edgecolors=color, linewidths=0.8, alpha=0.75)
        axes[1].loglog(x_line, (1.0 + x_line * x_line) ** (-m_filter), color=color, lw=1.8, label=fr"$m={m_filter}$")
    axes[1].set_xlabel(r"$\omega\tau_{\rm ETD}$", fontsize=10)
    axes[1].set_ylabel("Norm. spectrum", fontsize=10)
    axes[1].set_ylim(1e-10, 1.5)
    axes[1].legend(frameon=False, title="Filters to output", fontsize=7, title_fontsize=8)
    for ax in axes:
        ax.tick_params(labelsize=8)

    for ax, label in zip(axes, ["(a)", "(b)"]):
        style_axes(ax)
        ax.text(-0.14, 1.05, label, transform=ax.transAxes, ha="left", va="bottom", fontsize=12, fontweight="bold")
    save(fig, "FigureStochasticCollapse")


def plot_figure8() -> None:
    data = load("Figure8.npz")
    rows = data["map_rows"]
    eps_values = np.asarray(sorted(set(rows[:, 0])))
    wtau_values = np.asarray(sorted(set(rows[:, 1])))
    z = rows[:, 4].reshape(len(eps_values), len(wtau_values))
    boundary = rows[:, 7].reshape(len(eps_values), len(wtau_values))
    boundary_approach = 1.0 - boundary

    fig = plt.figure(figsize=(7.25, 2.05), constrained_layout=False)
    gs = fig.add_gridspec(
        1,
        5,
        width_ratios=[0.98, 0.045, 0.98, 0.045, 1.35],
        left=0.055,
        right=0.99,
        bottom=0.21,
        top=0.87,
        wspace=0.46,
    )
    axes = np.asarray([fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[0, 2]), fig.add_subplot(gs[0, 4])], dtype=object)
    cbar_axes = [fig.add_subplot(gs[0, 1]), fig.add_subplot(gs[0, 3])]
    z_plot = np.clip(z, 1e-3, None)
    contour_levels = [10**-2.5, 10**-2.0, 10**-1.5, 10**-1.0, 10**-0.5]
    label_fmt = {
        10**-2.5: r"$10^{-2.5}$",
        10**-2.0: r"$10^{-2}$",
        10**-1.5: r"$10^{-1.5}$",
        10**-1.0: r"$10^{-1}$",
        10**-0.5: r"$10^{-0.5}$",
    }
    for ax, cax, values, title in (
        (axes[0], cbar_axes[0], z_plot, "Relative RMS error"),
        (axes[1], cbar_axes[1], np.clip(boundary_approach, 1e-3, None), "Boundary index"),
    ):
        mesh = ax.pcolormesh(
            wtau_values,
            eps_values,
            values,
            shading="auto",
            cmap="magma",
            norm=LogNorm(vmin=1e-3, vmax=1.0),
            linewidth=0,
            edgecolors="none",
            antialiased=False,
            rasterized=True,
        )
        cs = ax.contour(wtau_values, eps_values, values, levels=contour_levels, colors="white", linewidths=1.0)
        labels = ax.clabel(cs, fmt=label_fmt, fontsize=7, inline=False)
        for txt in labels:
            txt.set_rotation(0)
            txt.set_color("white")
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel(r"$\omega\tau_{\rm ETD}$")
        if ax is axes[0]:
            ax.set_ylabel(r"Excursion $\epsilon_C$")
        else:
            ax.set_ylabel("")
        cbar = fig.colorbar(mesh, cax=cax, label=title)
        cbar.solids.set_edgecolor("face")
        style_colorbar(cbar)
        cbar.ax.yaxis.set_label_position("left")
        cbar.ax.yaxis.label.set_rotation(90)
        cbar.ax.yaxis.labelpad = 4

    examples = data["example_rows"]
    names = list(data["example_label_names"])
    colors = {0: PALETTE["blue"], 1: PALETTE["orange"], 2: PALETTE["red"]}
    for label_id in (0, 1, 2):
        pts = examples[examples[:, 0] == label_id]
        axes[2].plot(pts[:, 3], pts[:, 4], color=colors[label_id], lw=1.4)
        axes[2].plot(pts[:, 3], pts[:, 5], color=colors[label_id], lw=1.0, ls="--")
    axes[2].set_xlabel("Cycles")
    axes[2].set_ylabel("Complex concentration")
    axes[2].set_xlim(0.0, 2.0)
    axes[2].set_ylim(0.0, 1.5)
    regime_handles = [
        Line2D([0], [0], color=colors[label_id], lw=2.0, label=str(names[label_id]).title())
        for label_id in (0, 1, 2)
    ]
    style_handles = [
        Line2D([0], [0], color="0.15", lw=1.8, label="Full"),
        Line2D([0], [0], color="0.15", lw=1.4, ls="--", label="Local"),
    ]
    legend_regime = axes[2].legend(handles=regime_handles, frameon=False, loc="upper left")
    axes[2].add_artist(legend_regime)
    axes[2].legend(handles=style_handles, frameon=False, loc="upper right", handlelength=2.2)

    for ax in axes:
        ax.xaxis.labelpad = 2
        ax.yaxis.labelpad = 1
    finish_axes(axes, labels=["(a)", "(b)", "(c)"])
    save(fig, "Figure8")


PLOTTERS = {
    "1": plot_figure1,
    "2": plot_figure2,
    "3": plot_figure3,
    "4": plot_figure4,
    "5": plot_figure5,
    "6": plot_stochastic_cascade,
    "7": plot_figure7,
    "8": plot_figure8,
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--figures",
        nargs="*",
        choices=sorted(PLOTTERS),
        default=sorted(PLOTTERS),
        help="figure numbers to plot; default plots all main figures",
    )
    args = parser.parse_args()

    ensure_dirs()
    apply_style()
    for figure_id in args.figures:
        plotter = PLOTTERS[figure_id]
        print(f"[plot] {plotter.__name__}", flush=True)
        plotter()
    print(f"[plot] wrote figures to {OUT_DIR}", flush=True)


if __name__ == "__main__":
    main()
