#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

FORCE=0
STOCHASTIC_REPLICATES=32
STOCHASTIC_WORKERS=60

while [[ $# -gt 0 ]]; do
  case "$1" in
    --force)
      FORCE=1
      shift
      ;;
    --stochastic-replicates)
      STOCHASTIC_REPLICATES="$2"
      shift 2
      ;;
    --stochastic-workers)
      STOCHASTIC_WORKERS="$2"
      shift 2
      ;;
    *)
      echo "Unknown argument: $1" >&2
      exit 2
      ;;
  esac
done

for FIG in 1 2 3 4 5 6 7 8; do
  echo "[main_v4 figures] Figure ${FIG}: generating data"
  DATA_ARGS=(--figures "$FIG")
  if [[ "$FORCE" -eq 1 ]]; then
    DATA_ARGS+=(--force)
  fi
  if [[ "$FIG" == "6" ]]; then
    DATA_ARGS+=(--stochastic-replicates "$STOCHASTIC_REPLICATES" --stochastic-workers "$STOCHASTIC_WORKERS")
  fi
  python3 scripts/generate_data.py "${DATA_ARGS[@]}"

  echo "[main_v4 figures] Figure ${FIG}: plotting PNG"
  python3 scripts/plot_figures.py --figures "$FIG"
done

echo "[main_v4 figures] complete: figures/Figure1.png ... figures/Figure8.png"

