# Effective time delay as a local bandwidth measure in biochemical networks

**Junghun Chae and C.-M. Ghim**

## Main-text figure reproduction

This directory contains the code needed to reproduce the six figures in the
main text. Numerical calculations and plotting are separated so that figure
styling can be changed without repeating the simulations.

1. `scripts/generate_data.py` writes one numerical dataset for each figure to
   `data/Fig1.npz` through `data/Fig6.npz`.
2. `scripts/plot_figures.py` reads those datasets and writes 600-dpi PNG files
   to `figures/Fig1.png` through `figures/Fig6.png`.
3. `run_all.py` removes the intermediate `data/` directory after plotting.

## Run the complete workflow

From the repository root, reproduce all six main-text figures with:

```bash
python3 Chae_Ghim/run_all.py
```

Common options are:

```bash
# Recompute numerical data even when matching files already exist.
python3 Chae_Ghim/run_all.py --force

# Reproduce selected figures.
python3 Chae_Ghim/run_all.py --figures 1 3 5

# Plot data retained by an earlier --data-only run.
python3 Chae_Ghim/run_all.py --plot-only

# Generate and retain the numerical data without plotting.
python3 Chae_Ghim/run_all.py --data-only --force
```

`--data-only` is the only mode that retains the generated datasets. A normal
run and a `--plot-only` run remove the intermediate `data/` directory after
successful plotting.

| Main-text figure | Numerical data | Reproduced figure |
| --- | --- | --- |
| Fig. 1 | `data/Fig1.npz` | `figures/Fig1.png` |
| Fig. 2 | `data/Fig2.npz` | `figures/Fig2.png` |
| Fig. 3 | `data/Fig3.npz` | `figures/Fig3.png` |
| Fig. 4 | `data/Fig4.npz` | `figures/Fig4.png` |
| Fig. 5 | `data/Fig5.npz` | `figures/Fig5.png` |
| Fig. 6 | `data/Fig6.npz` | `figures/Fig6.png` |

## Stochastic calculations

For Fig. 4, use `--stochastic-replicates` to set the number of independent
trajectories and `--stochastic-workers` to set the number of parallel worker
processes. For example:

```bash
python3 Chae_Ghim/run_all.py --figures 4 --force \
  --stochastic-replicates 1000 --stochastic-workers 60
```

## Dependencies

Install the Python dependencies with:

```bash
python3 -m pip install -r Chae_Ghim/requirements.txt
```
