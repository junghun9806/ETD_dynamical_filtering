# Effective time delay as a local bandwidth measure in biochemical networks

**Junghun Chae and C.-M. Ghim**

## Main-text figure reproduction

This repository contains the code needed to reproduce the six figures in the
main text. All commands below assume that the repository root is the current
working directory. Numerical calculations and plotting are separated so that
figure styling can be changed without repeating the simulations.

1. `scripts/generate_data.py` writes one numerical dataset for each figure to
   `data/Fig1.npz` through `data/Fig6.npz`.
2. `scripts/plot_figures.py` reads those datasets and writes 600-dpi PNG files
   to `figures/Fig1.png` through `figures/Fig6.png`.
3. `run_all.py` removes the intermediate `data/` directory after plotting.

## Run the complete workflow

Reproduce all six main-text figures with:

```bash
python3 run_all.py
```

Common options are:

```bash
# Recompute numerical data even when matching files already exist.
python3 run_all.py --force

# Reproduce selected figures.
python3 run_all.py --figures 1 3 5

# Plot data retained by an earlier --data-only run.
python3 run_all.py --plot-only

# Generate and retain the numerical data without plotting.
python3 run_all.py --data-only --force
```

`--data-only` is the only mode that retains the generated datasets. A normal
run and a `--plot-only` run remove the intermediate `data/` directory after
successful plotting.

| Main-text figure | Numerical data | Reproduced figure |
| --- | --- | --- |
| Fig. 1 | `data/Fig1.npz` | `figures/Fig1.png` |
| Fig. 2 | `data/Fig2.npz` | `figures/Fig2.png` |
| Fig. 3 | `data/Fig3.npz` | `figures/Fig3.png` |
| Fig. 4 | `data/Fig4.npz` | `figures/Fig4.png` |
| Fig. 5 | `data/Fig5.npz` | `figures/Fig5.png` |
| Fig. 6 | `data/Fig6.npz` | `figures/Fig6.png` |

## Figure 4 stochastic calculations

Figure 4 is reproduced on one server using local multiprocessing; no external
job runner is required. The manuscript settings are the defaults:

- 10,000 trajectories for each noise-source step in panels (a,b);
- 1,000 log-uniformly sampled values of beta in panels (d,e);
- 1,000 independent trajectories for each beta;
- all CPU cores detected on the local server.

To reproduce Figure 4 alone with these settings, run:

```bash
python3 run_all.py --figures 4 --force
```

The full calculation is intentionally expensive. A smaller run can be used to
check the workflow and plotting code before starting the manuscript-scale run:

```bash
python3 run_all.py --figures 4 --force \
  --source-replicates 10 \
  --fixed-m-beta-count 10 \
  --fixed-m-replicates 10 \
  --stochastic-workers 4
```

The smaller run does not reproduce the sampling density or statistical
precision of the manuscript figure.

## Final manuscript preparation

The scripts reproduce the numerical content and baseline layout of the
figures. The publication files may still require small manual adjustments
after export, such as fine panel spacing, label placement, or format-specific
alignment. Such adjustments should not change the plotted data, axis limits,
or numerical results.

## Dependencies

Install the Python dependencies with:

```bash
python3 -m pip install -r requirements.txt
```
