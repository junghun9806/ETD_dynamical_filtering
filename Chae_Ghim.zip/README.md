# Main_v4 Figure Pipeline

This directory regenerates the six figures included by
`tex/main/Main_v4.tex`. Numerical simulation and plotting are kept separate:

1. `scripts/generate_data.py` writes intermediate `.npz` data to `data/`.
2. `scripts/plot_figures.py` reads those data and writes 600-dpi PNG files to
   `figures/`.
3. `run_all.py` deletes the intermediate data after successful plotting.

## Run the pipeline

From the repository root, regenerate all six figures with:

```bash
python3 main_v4_figure_pipeline/run_all.py
```

Common options are:

```bash
# Recompute numerical data instead of reusing existing files.
python3 main_v4_figure_pipeline/run_all.py --force

# Regenerate selected manuscript figures.
python3 main_v4_figure_pipeline/run_all.py --figures 1 3 5

# Replot data retained by a previous --data-only run.
python3 main_v4_figure_pipeline/run_all.py --plot-only

# Recompute data without plotting.
python3 main_v4_figure_pipeline/run_all.py --data-only --force
```

`--data-only` is the only mode that retains the generated data. A normal run
and a `--plot-only` run remove the entire `data/` directory after plotting.

The manuscript numbers and the retained numerical dataset identifiers are not
the same because the current Fig. 1 merges two earlier figures. `run_all.py`
handles this mapping automatically:

| Main_v4 figure | Required data | Output basename |
| --- | --- | --- |
| Fig. 1 | `Figure2.npz`, `Figure3.npz` | `Fig1` |
| Fig. 2 | `Figure4.npz` | `Fig2` |
| Fig. 3 | `Figure5.npz` | `Fig3` |
| Fig. 4 | `Figure6.npz` | `Fig4` |
| Fig. 5 | `Figure7.npz` | `Fig5_vertical` |
| Fig. 6 | `Figure8.npz` | `Fig6` |

Each basename is produced with the `.png` extension.
The files in this pipeline are not copied automatically into
`tex/Figs/figs_curated/`, which prevents a test run from overwriting manually
curated manuscript graphics.

## Stochastic figure

Fig. 4 uses 32 replicate trajectories by default for quick regeneration. A
higher-statistics run can be made with:

```bash
python3 main_v4_figure_pipeline/run_all.py --figures 4 --force \
  --stochastic-replicates 1000 --stochastic-workers 60
```

Install dependencies with:

```bash
python3 -m pip install -r main_v4_figure_pipeline/requirements.txt
```
