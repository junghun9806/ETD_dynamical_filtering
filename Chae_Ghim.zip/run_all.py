#!/usr/bin/env python3
"""Regenerate the six figures in the Main text.

The workflow is intentionally split into two steps:

1. ``scripts/generate_data.py`` solves ODE/SDE systems and writes result data.
2. ``scripts/plot_figures.py`` reads those data files and writes PNG figures.
3. Intermediate data are removed after successful plotting.
"""

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SCRIPT_DIR = ROOT / "scripts"
DATA_DIR = ROOT / "data"

# Numerical data retain their original dataset identifiers, while the keys in
# this map follow the current manuscript figure numbers.
MANUSCRIPT_DATA = {
    "1": ("2", "3"),
    "2": ("4",),
    "3": ("5",),
    "4": ("6",),
    "5": ("7",),
    "6": ("8",),
}


def run_script(script_name: str, extra_args: list[str] | None = None) -> None:
    script_path = SCRIPT_DIR / script_name
    env = os.environ.copy()
    env.setdefault("MPLCONFIGDIR", "/tmp/mpl")
    print(f"[figures] running {script_name}", flush=True)
    subprocess.run(
        [sys.executable, str(script_path), *(extra_args or [])],
        cwd=str(SCRIPT_DIR),
        env=env,
        check=True,
    )


def remove_intermediate_data() -> None:
    if DATA_DIR.exists():
        shutil.rmtree(DATA_DIR)
        print(f"[figures] removed intermediate data from {DATA_DIR}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true", help="regenerate existing data files")
    parser.add_argument(
        "--figures",
        nargs="*",
        choices=sorted(MANUSCRIPT_DATA),
        default=sorted(MANUSCRIPT_DATA),
        help="figure numbers to regenerate; default regenerates all main figures",
    )
    parser.add_argument("--data-only", action="store_true", help="generate data but do not plot")
    parser.add_argument("--plot-only", action="store_true", help="plot from existing data without regenerating data")
    parser.add_argument(
        "--stochastic-replicates",
        type=int,
        default=32,
        help="independent trajectories for stochastic cascade spectra and variance estimates",
    )
    parser.add_argument(
        "--stochastic-workers",
        type=int,
        default=60,
        help="worker processes for stochastic cascade replicate simulations",
    )
    args = parser.parse_args()

    figures = [str(fig) for fig in args.figures]
    data_figures = sorted(
        {data_id for figure_id in figures for data_id in MANUSCRIPT_DATA[figure_id]},
        key=int,
    )
    if args.data_only and args.plot_only:
        raise SystemExit("--data-only and --plot-only cannot be used together")

    if not args.plot_only:
        print(
            f"[figures] manuscript figures {', '.join(figures)} require data sets {', '.join(data_figures)}",
            flush=True,
        )
        data_args = [
            "--figures",
            *data_figures,
            "--stochastic-replicates",
            str(args.stochastic_replicates),
            "--stochastic-workers",
            str(args.stochastic_workers),
        ]
        if args.force:
            data_args.append("--force")
        run_script("generate_data.py", data_args)

    if not args.data_only:
        run_script("plot_figures.py", ["--figures", *figures])
        remove_intermediate_data()

    print("[figures] complete", flush=True)


if __name__ == "__main__":
    main()
