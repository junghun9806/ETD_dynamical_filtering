#!/usr/bin/env python3
"""Reproduce the six figures in the main text.

The workflow is intentionally split into two steps:

1. ``scripts/generate_data.py`` solves ODE/SDE systems and writes result data.
2. ``scripts/plot_figures.py`` reads those data files and writes PNG figures.
3. Intermediate data are removed after successful plotting.
"""

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SCRIPT_DIR = ROOT / "scripts"
DATA_DIR = ROOT / "data"

FIGURE_IDS = tuple(str(index) for index in range(1, 7))


def run_script(script_name: str, extra_args: list[str] | None = None) -> None:
    script_path = SCRIPT_DIR / script_name
    env = os.environ.copy()
    env.setdefault("MPLCONFIGDIR", "/tmp/mpl")
    print(f"[figures] running {script_name}", flush=True)
    subprocess.run(
        [sys.executable, str(script_path), *(extra_args or [])],
        cwd=str(SCRIPT_DIR),
        env=env,
        check=True,
    )


def remove_intermediate_data() -> None:
    if DATA_DIR.exists():
        shutil.rmtree(DATA_DIR)
        print(f"[figures] removed intermediate data from {DATA_DIR}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true", help="regenerate existing data files")
    parser.add_argument(
        "--figures",
        nargs="*",
        choices=FIGURE_IDS,
        default=FIGURE_IDS,
        help="figure numbers to reproduce; default reproduces all main-text figures",
    )
    parser.add_argument("--data-only", action="store_true", help="generate data but do not plot")
    parser.add_argument("--plot-only", action="store_true", help="plot from existing data without regenerating data")
    parser.add_argument(
        "--source-replicates",
        "--stochastic-replicates",
        dest="source_replicates",
        type=int,
        default=10000,
        help="trajectories per noise-source step in Fig. 4(a,b)",
    )
    parser.add_argument("--fixed-m-beta-count", type=int, default=1000, help="beta values in Fig. 4(d,e)")
    parser.add_argument("--fixed-m-replicates", type=int, default=1000, help="trajectories per beta in Fig. 4(d,e)")
    parser.add_argument(
        "--stochastic-workers",
        type=int,
        default=max(1, os.cpu_count() or 1),
        help="local worker processes used on this server",
    )
    args = parser.parse_args()

    figures = [str(fig) for fig in args.figures]
    if args.data_only and args.plot_only:
        raise SystemExit("--data-only and --plot-only cannot be used together")

    if not args.plot_only:
        print(
            f"[figures] generating data for Fig. {', '.join(figures)}",
            flush=True,
        )
        data_args = [
            "--figures",
            *figures,
            "--source-replicates",
            str(args.source_replicates),
            "--fixed-m-beta-count",
            str(args.fixed_m_beta_count),
            "--fixed-m-replicates",
            str(args.fixed_m_replicates),
            "--stochastic-workers",
            str(args.stochastic_workers),
        ]
        if args.force:
            data_args.append("--force")
        run_script("generate_data.py", data_args)

    if not args.data_only:
        run_script("plot_figures.py", ["--figures", *figures])
        remove_intermediate_data()

    print("[figures] complete", flush=True)


if __name__ == "__main__":
    main()
