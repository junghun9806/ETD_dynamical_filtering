#!/usr/bin/env python3
"""Generate ODE-based data for the main manuscript figures.

This script performs the numerical work only.  The plotting script
``plot_figures.py`` reads the saved ``.npz`` files and creates the manuscript
figure formats, so styling changes do not require re-running simulations.
"""

import argparse
import math
import os
from multiprocessing import Pool
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import solve_continuous_lyapunov
from scipy.signal import welch


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
WORKERS = max(1, os.cpu_count() or 1)
RTOL = 1e-10
ATOL = 1e-10
STOCHASTIC_DT = 0.01
STOCHASTIC_BURN_STEPS = 2**15
STOCHASTIC_RELAXATION_TIMES = 50.0
STOCHASTIC_SAMPLES = 2**17
STOCHASTIC_BINS = 56
BETA_SAMPLE_SEED = 20260825
BETA_BIN_OFFSET_SEED = 20260826


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def should_skip(path: Path, force: bool) -> bool:
    return path.exists() and not force


def save_npz(path: Path, force: bool, **arrays) -> None:
    if should_skip(path, force):
        print(f"[data] skip existing {path.name}", flush=True)
        return
    np.savez_compressed(path, **arrays)
    print(f"[data] wrote {path}", flush=True)


def parallel_map(func, tasks, chunksize=16):
    if not tasks:
        return []
    with Pool(processes=WORKERS) as pool:
        return pool.map(func, tasks, chunksize=chunksize)


def cycles_for_frequency(omega: float, rate: float) -> int:
    """Choose enough forcing cycles for transients to decay."""
    rate = max(rate, 1e-9)
    cycles = int(math.ceil(12.0 + 8.0 * omega / (2.0 * math.pi * rate)))
    return int(np.clip(cycles, 18, 90))


def harmonic_amplitude_phase(theta: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    centered = y - np.mean(y)
    sin_coeff = 2.0 * np.mean(centered * np.sin(theta))
    cos_coeff = 2.0 * np.mean(centered * np.cos(theta))
    amplitude = math.sqrt(sin_coeff * sin_coeff + cos_coeff * cos_coeff)
    phase = math.atan2(cos_coeff, sin_coeff)
    return amplitude, phase


def interpolate_cutoff(freq: np.ndarray, gain: np.ndarray) -> float:
    target = 1.0 / math.sqrt(2.0)
    order = np.argsort(freq)
    freq = np.asarray(freq)[order]
    gain = np.asarray(gain)[order]
    idx = np.where(gain <= target)[0]
    if len(idx) == 0:
        return float("nan")
    i = int(idx[0])
    if i == 0:
        return float(freq[0])
    x0, x1 = math.log(freq[i - 1]), math.log(freq[i])
    y0, y1 = gain[i - 1] - target, gain[i] - target
    if abs(y1 - y0) < 1e-12:
        return float(freq[i])
    return float(math.exp(x0 - y0 * (x1 - x0) / (y1 - y0)))


def first_order_gain_phase_task(args):
    beta, omega, amp = args
    cycles = cycles_for_frequency(omega, beta)
    theta_end = 2.0 * math.pi * cycles
    theta_eval = np.linspace(theta_end - 4.0 * math.pi, theta_end, 480)

    def rhs(theta, y):
        return [beta * (amp * math.sin(theta) - y[0]) / omega]

    sol = solve_ivp(rhs, (0.0, theta_end), [0.0], t_eval=theta_eval, rtol=RTOL, atol=ATOL, method="LSODA")
    if not sol.success:
        return omega, np.nan, np.nan
    out_amp, phase = harmonic_amplitude_phase(sol.t, sol.y[0])
    return omega, out_amp / amp, phase


def ppi_parameter_sets(rng: np.random.Generator, n_samples: int = 10000) -> dict[str, np.ndarray]:
    """Sample PPI parameters for the reversible-binding panels in Fig. 1."""
    a0 = rng.uniform(1.0, 10.0, n_samples)
    b0 = rng.uniform(1.0, 10.0, n_samples)
    ka = 10 ** rng.uniform(-1.0, 2.0, n_samples)
    kd = 10 ** rng.uniform(-1.0, 2.0, n_samples)
    k = kd / ka
    c_ss = 0.5 * (k + a0 + b0 - np.sqrt((k + a0 + b0) ** 2 - 4.0 * a0 * b0))
    lam = ka * (a0 + b0 - 2.0 * c_ss) + kd
    tau = 1.0 / lam
    sensitivity = ka * (b0 - c_ss)
    margin_up = np.minimum(a0, b0) - c_ss
    return {
        "a0": a0,
        "b0": b0,
        "ka": ka,
        "kd": kd,
        "c_ss": c_ss,
        "lambda": lam,
        "tau": tau,
        "sensitivity": sensitivity,
        "margin_up": margin_up,
    }


def ppi_scalar_parameter_set(a0: float = 2.0, b0: float = 2.0, ka: float = 1.0, kd: float = 1.0) -> dict[str, np.ndarray]:
    params = ppi_parameter_sets(np.random.default_rng(0), 1)
    params["a0"][:] = a0
    params["b0"][:] = b0
    params["ka"][:] = ka
    params["kd"][:] = kd
    k = params["kd"] / params["ka"]
    params["c_ss"][:] = 0.5 * (k + a0 + b0 - np.sqrt((k + a0 + b0) ** 2 - 4.0 * a0 * b0))
    params["lambda"][:] = ka * (a0 + b0 - 2.0 * params["c_ss"]) + kd
    params["tau"][:] = 1.0 / params["lambda"]
    params["sensitivity"][:] = ka * (b0 - params["c_ss"])
    params["margin_up"][:] = min(a0, b0) - params["c_ss"]
    return params


def ppi_rows(params: dict[str, np.ndarray]) -> list[tuple[float, ...]]:
    keys = ("a0", "b0", "ka", "kd", "c_ss", "lambda", "tau", "sensitivity", "margin_up")
    return [tuple(float(params[key][idx]) for key in keys) for idx in range(len(params["a0"]))]


def solve_ppi_step_relaxation(task: tuple[tuple[float, ...], float]) -> float:
    """Measure the 1/e relaxation after a sampled upward perturbation."""
    row, perturbation_fraction = task
    a0, b0, ka, kd, c_ss, lam, _tau, _sensitivity, margin_up = row
    c0 = c_ss + perturbation_fraction * margin_up
    threshold = abs(c0 - c_ss) / math.e

    def rhs(_t, y):
        c = y[0]
        return [ka * (a0 - c) * (b0 - c) - kd * c]

    def event(_t, y):
        return abs(y[0] - c_ss) - threshold

    event.terminal = True
    event.direction = -1
    sol = solve_ivp(rhs, (0.0, 8.0 / lam), [c0], events=event, rtol=RTOL, atol=ATOL)
    if len(sol.t_events[0]) > 0:
        return float(sol.t_events[0][0])
    return float(sol.t[-1])


def solve_ppi_forced_gain(task: tuple[tuple[float, ...], str, float, float]) -> tuple[float, float]:
    """Measure sinusoidal PPI response gain with a direct solve_ivp call."""
    row, omega_mode, omega_value, amp_fraction = task
    a0, b0, ka, kd, c_ss, lam, _tau, _sensitivity, _margin_up = row
    omega = omega_value * lam if omega_mode == "scaled" else omega_value
    omega_tau = omega / lam
    amp_in = amp_fraction * 0.5 * (a0 + b0)
    if omega <= 0.0 or amp_in <= 0.0:
        return float(omega_tau), float("nan")

    period = 2.0 * math.pi / omega
    t_end = 16.0 * period
    t_eval = np.linspace(t_end - 4.0 * period, t_end, 720)

    def rhs(t, y):
        c = y[0]
        a_t = a0 + amp_in * math.sin(omega * t)
        return [ka * (a_t - c) * (b0 - c) - kd * c]

    sol = solve_ivp(rhs, (0.0, t_end), [c_ss], t_eval=t_eval, rtol=RTOL, atol=ATOL, method="LSODA")
    if not sol.success:
        return float(omega_tau), float("nan")

    t = sol.t
    y = sol.y[0]
    centered = y - np.mean(y)
    sin_coeff = 2.0 * np.mean(centered * np.sin(omega * t))
    cos_coeff = 2.0 * np.mean(centered * np.cos(omega * t))
    measured_amp = math.sqrt(sin_coeff**2 + cos_coeff**2)

    k = kd / ka
    a_t = a0 + amp_in * np.sin(omega * t)
    c_qs = 0.5 * (k + a_t + b0 - np.sqrt((k + a_t + b0) ** 2 - 4.0 * a_t * b0))
    qs_centered = c_qs - np.mean(c_qs)
    qs_sin_coeff = 2.0 * np.mean(qs_centered * np.sin(omega * t))
    qs_cos_coeff = 2.0 * np.mean(qs_centered * np.cos(omega * t))
    qs_amp = math.sqrt(qs_sin_coeff**2 + qs_cos_coeff**2)
    return float(omega_tau), float(measured_amp / max(qs_amp, 1e-14))


def compute_figure1_binding_data() -> dict[str, np.ndarray]:
    rng = np.random.default_rng(4)
    params = ppi_parameter_sets(rng, n_samples=10000)
    amp_fraction_samples = rng.uniform(0.01, 0.5, len(params["tau"]))
    omega_tau = 10 ** rng.uniform(-2.0, 0.85, len(params["tau"]))
    perturbation_fraction_samples = rng.uniform(0.0, 0.5, len(params["tau"]))
    rows = ppi_rows(params)

    relaxation_tasks = list(zip(rows, perturbation_fraction_samples))
    relaxation_time = np.asarray(parallel_map(solve_ppi_step_relaxation, relaxation_tasks, chunksize=32), dtype=float)

    amp_fraction_grid = np.linspace(0.01, 0.5, 70)
    omega_grid = np.linspace(0.05, 5.0, 70)
    aa, ww = np.meshgrid(amp_fraction_grid, omega_grid)
    base_row = ppi_rows(ppi_scalar_parameter_set(a0=2.0, b0=2.0, ka=1.0, kd=1.0))[0]
    heat_tasks = [
        (base_row, "absolute", float(omega), float(amp_fraction))
        for amp_fraction, omega in zip(aa.ravel(), ww.ravel())
    ]
    heat_gain = np.asarray([gain for _, gain in parallel_map(solve_ppi_forced_gain, heat_tasks, chunksize=8)], dtype=float)

    omega_fixed = 0.5
    fixed_tasks = [
        (row, "absolute", omega_fixed, float(amp_fraction))
        for row, amp_fraction in zip(rows, amp_fraction_samples)
    ]
    fixed_gain = np.asarray([gain for _, gain in parallel_map(solve_ppi_forced_gain, fixed_tasks, chunksize=16)], dtype=float)

    collapse_tasks = [
        (row, "scaled", float(wtau), float(amp_fraction))
        for row, wtau, amp_fraction in zip(rows, omega_tau, amp_fraction_samples)
    ]
    collapse_results = parallel_map(solve_ppi_forced_gain, collapse_tasks, chunksize=16)
    collapse_omega_tau = np.asarray([wtau for wtau, _ in collapse_results], dtype=float)
    collapse_gain = np.asarray([gain for _, gain in collapse_results], dtype=float)

    return {
        "a0": params["a0"],
        "b0": params["b0"],
        "ka": params["ka"],
        "kd": params["kd"],
        "c_ss": params["c_ss"],
        "amp_fraction": amp_fraction_samples,
        "perturbation_fraction": perturbation_fraction_samples,
        "tau": params["tau"],
        "relaxation_time": relaxation_time,
        "heat_amp_fraction": amp_fraction_grid,
        "heat_omega": omega_grid,
        "heat_gain": heat_gain.reshape(ww.shape),
        "omega_fixed": np.asarray([omega_fixed], dtype=float),
        "fixed_tau": params["tau"],
        "fixed_gain": fixed_gain,
        "collapse_omega_tau": collapse_omega_tau,
        "collapse_gain": collapse_gain,
    }


def chain_gain_phase_task(args):
    if len(args) == 4:
        betas, omega, amp, output_index = args
        min_cycles = 0
        n_eval = 520
    else:
        betas, omega, amp, output_index, min_cycles, n_eval = args
    betas = np.asarray(betas, dtype=float)
    n_step = len(betas)
    output_index = n_step - 1 if output_index is None else output_index
    cycles = max(cycles_for_frequency(omega, float(np.min(betas))), int(min_cycles))
    theta_end = 2.0 * math.pi * cycles
    theta_eval = np.linspace(theta_end - 4.0 * math.pi, theta_end, int(n_eval))

    def rhs(theta, y):
        dydtheta = np.empty(n_step, dtype=float)
        u = amp * math.sin(theta)
        dydtheta[0] = betas[0] * (u - y[0]) / omega
        for idx in range(1, n_step):
            dydtheta[idx] = betas[idx] * (y[idx - 1] - y[idx]) / omega
        return dydtheta

    sol = solve_ivp(rhs, (0.0, theta_end), np.zeros(n_step), t_eval=theta_eval, rtol=RTOL, atol=ATOL, method="LSODA")
    if not sol.success:
        return omega, np.nan, np.nan
    out_amp, phase = harmonic_amplitude_phase(sol.t, sol.y[output_index])
    return omega, out_amp / amp, phase


def simulate_chain_pulse(n_step: int, beta: float = 1.0):
    """Simulate a Gaussian input pulse with rates and time in h^-1 and h."""
    betas = np.full(n_step, beta)
    t_eval = np.linspace(-10.0, 30.0, 2500)

    def pulse(t):
        return math.exp(-0.5 * (t / 0.5) ** 2)

    def rhs(t, y):
        dydt = np.empty(n_step, dtype=float)
        dydt[0] = beta * (pulse(t) - y[0])
        for idx in range(1, n_step):
            dydt[idx] = betas[idx] * (y[idx - 1] - y[idx])
        return dydt

    sol = solve_ivp(rhs, (t_eval[0], t_eval[-1]), np.zeros(n_step), t_eval=t_eval, rtol=RTOL, atol=ATOL, method="LSODA")
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.t, sol.y[-1]


def hetero_cutoff_worker(args):
    betas_tuple, freq_hetero = args
    betas = np.asarray(betas_tuple, dtype=float)
    rows = [chain_gain_phase_task((tuple(betas), float(w), 1.0, None)) for w in freq_hetero]
    gains = np.asarray([r[1] for r in rows], dtype=float)
    cutoff = interpolate_cutoff(np.asarray(freq_hetero, dtype=float), gains)
    delays = 1.0 / betas
    return (float(np.sum(delays)), cutoff, float(np.max(delays) / np.sum(delays)), *betas)


def compute_figure1_cascade_data() -> dict[str, np.ndarray]:
    omega_a = np.logspace(-1, 2, 90)
    m_rows = parallel_map(chain_gain_phase_task, [((1.0,), float(w), 1.0, None) for w in omega_a], chunksize=12)
    p_rows = parallel_map(chain_gain_phase_task, [((0.65, 1.7), float(w), 1.0, None) for w in omega_a], chunksize=12)

    x_b = np.logspace(-1, 2, 90)
    tau_protein = 1.0 / 0.65 + 1.0 / 1.7
    mb_rows = parallel_map(chain_gain_phase_task, [((1.0,), float(x), 1.0, None) for x in x_b], chunksize=12)
    pb_rows = parallel_map(chain_gain_phase_task, [((0.65, 1.7), float(x / tau_protein), 1.0, None) for x in x_b], chunksize=12)

    x_scaled = np.logspace(-1, 2, 72)
    cascade_rows = []
    tasks = []
    for n_step in range(1, 26):
        for xval in x_scaled:
            omega = float(xval / n_step)
            tasks.append((n_step, xval, omega))
    sim_rows = parallel_map(
        chain_gain_phase_task,
        [((1.0,) * n, omega, 1.0, None, 60, 1400) for n, _x, omega in tasks],
        chunksize=8,
    )
    for (n_step, xval, omega), (_omega, gain, phase) in zip(tasks, sim_rows):
        cascade_rows.append((n_step, xval, omega, gain, phase))

    omega_delay = np.logspace(-1.2, 1.2, 80)
    delay_rows = []
    for n_step in (1, 2, 4, 8):
        rows = parallel_map(
            chain_gain_phase_task,
            [((1.0,) * n_step, float(w), 1.0, None, 80, 2000) for w in omega_delay],
            chunksize=10,
        )
        phases = np.unwrap(np.asarray([r[2] for r in rows], dtype=float))
        tau_phase = -phases / omega_delay
        tau_group = -np.gradient(phases, omega_delay)
        for omega, phase_delay, group_delay in zip(omega_delay, tau_phase / n_step, tau_group / n_step):
            delay_rows.append((n_step, omega, phase_delay, group_delay))

    return {
        "panel_a_omega": omega_a,
        "panel_a_m_gain": np.asarray([r[1] for r in m_rows]),
        "panel_a_p_gain": np.asarray([r[1] for r in p_rows]),
        "panel_b_x": x_b,
        "panel_b_m_gain": np.asarray([r[1] for r in mb_rows]),
        "panel_b_p_gain": np.asarray([r[1] for r in pb_rows]),
        "cascade_rows": np.asarray(cascade_rows, dtype=float),
        "delay_rows": np.asarray(delay_rows, dtype=float),
    }


def generate_figure1(force: bool) -> None:
    path = DATA_DIR / "Fig1.npz"
    if should_skip(path, force):
        print(f"[data] skip existing {path.name}", flush=True)
        return

    binding_data = compute_figure1_binding_data()
    cascade_data = compute_figure1_cascade_data()
    local_line_x = np.logspace(-2.0, 1.0, 280)
    local_rows = parallel_map(
        first_order_gain_phase_task,
        [(1.0, float(omega), 1.0) for omega in local_line_x],
        chunksize=12,
    )
    local_rows = np.asarray(local_rows, dtype=float)
    save_npz(
        path,
        True,
        **binding_data,
        local_line_x=local_rows[:, 0],
        local_line_gain=local_rows[:, 1],
        **cascade_data,
    )


def feedback_steady_from_ode(theta: float):
    def rhs(_t, y):
        m, p = y
        return [math.exp(-theta * p) - m, m - p]

    sol = solve_ivp(rhs, (0.0, 240.0), [1.0, 1.0], rtol=RTOL, atol=ATOL, method="LSODA")
    if not sol.success:
        raise RuntimeError(sol.message)
    return float(sol.y[0, -1]), float(sol.y[1, -1])


def feedback_gain_phase_task(args):
    theta, omega, amp, m_ss, p_ss = args
    cycles = cycles_for_frequency(omega, 1.0)
    theta_end = 2.0 * math.pi * cycles
    theta_eval = np.linspace(theta_end - 4.0 * math.pi, theta_end, 520)

    def rhs(phase, y):
        m, p = y
        return [
            (math.exp(-theta * p) - m + amp * math.sin(phase)) / omega,
            (m - p) / omega,
        ]

    sol = solve_ivp(rhs, (0.0, theta_end), [m_ss, p_ss], t_eval=theta_eval, rtol=RTOL, atol=ATOL, method="LSODA")
    if not sol.success:
        return theta, omega, np.nan, np.nan
    out_amp, phase = harmonic_amplitude_phase(sol.t, sol.y[1])
    return theta, omega, out_amp / amp, phase


def generate_figure2(force: bool) -> None:
    path = DATA_DIR / "Fig2.npz"
    if should_skip(path, force):
        print(f"[data] skip existing {path.name}", flush=True)
        return

    theta_values = np.linspace(0.0, 10.0, 121)
    steady_rows = []
    for theta in theta_values:
        m_ss, p_ss = feedback_steady_from_ode(float(theta))
        loop = theta * math.exp(-theta * p_ss)
        steady_rows.append((theta, m_ss, p_ss, loop))

    theta_gain_values = (0.0, 0.5, 1.0, 5.0, 10.0)
    omega_grid = np.logspace(-2.2, 1.5, 80)
    steady_lookup = {round(r[0], 10): (r[1], r[2]) for r in steady_rows}
    low_gain = {}
    for theta in theta_gain_values:
        m_ss, p_ss = feedback_steady_from_ode(theta)
        _, _, gain, phase = feedback_gain_phase_task((theta, 0.02, 0.02, m_ss, p_ss))
        low_gain[theta] = max(gain, 1e-14)

    transfer_rows = []
    gain_tasks = []
    for theta in theta_gain_values:
        m_ss, p_ss = feedback_steady_from_ode(theta)
        loop = theta * math.exp(-theta * p_ss)
        a_theta = 1.0 + loop
        b_theta = 2.0
        for omega in omega_grid:
            transfer_gain = a_theta / math.sqrt((a_theta - omega * omega) ** 2 + (b_theta * omega) ** 2)
            transfer_rows.append((theta, float(omega), transfer_gain))
            gain_tasks.append((theta, float(omega), 0.02, m_ss, p_ss))
    gain_raw = parallel_map(feedback_gain_phase_task, gain_tasks, chunksize=8)
    gain_rows = [(theta, omega, gain / low_gain[theta], phase) for theta, omega, gain, phase in gain_raw]

    metric_rows = []
    metric_omega = np.logspace(-2.0, 1.4, 56)
    for theta, m_ss, p_ss, loop in steady_rows:
        rows = parallel_map(
            feedback_gain_phase_task,
            [(float(theta), float(w), 0.02, float(m_ss), float(p_ss)) for w in metric_omega],
            chunksize=8,
        )
        gains = np.asarray([r[2] for r in rows], dtype=float)
        phases = np.unwrap(np.asarray([r[3] for r in rows], dtype=float))
        norm_gains = gains / max(gains[0], 1e-14)
        cutoff = interpolate_cutoff(metric_omega, norm_gains)
        low_delay = -phases[0] / metric_omega[0]
        metric_rows.append((theta, p_ss, loop, low_delay, cutoff))

    ode_check_rows = []
    for theta in theta_gain_values:
        selected = [r for r in gain_rows if abs(r[0] - theta) < 1e-12]
        for row in selected[::4]:
            ode_check_rows.append(row)

    save_npz(
        path,
        True,
        steady_rows=np.asarray(steady_rows, dtype=float),
        transfer_rows=np.asarray(transfer_rows, dtype=float),
        gain_rows=np.asarray(gain_rows, dtype=float),
        metric_rows=np.asarray(metric_rows, dtype=float),
        ode_check_rows=np.asarray(ode_check_rows, dtype=float),
    )


def generate_figure3(force: bool) -> None:
    path = DATA_DIR / "Fig3.npz"
    if should_skip(path, force):
        print(f"[data] skip existing {path.name}", flush=True)
        return

    omega_grid = np.logspace(-2, 1.5, 78)
    heat_tasks = []
    for n_step in range(1, 11):
        for omega in omega_grid:
            heat_tasks.append((n_step, float(omega)))
    heat_raw = parallel_map(
        chain_gain_phase_task,
        [((1.0,) * n, omega, 1.0, None) for n, omega in heat_tasks],
        chunksize=8,
    )
    heat_rows = [(n, omega, gain) for (n, omega), (_omega, gain, _phase) in zip(heat_tasks, heat_raw)]

    cutoff_rows = []
    for n_step in range(1, 11):
        points = [(omega, gain) for n, omega, gain in heat_rows if n == n_step]
        cutoff_rows.append((n_step, interpolate_cutoff(np.asarray([p[0] for p in points]), np.asarray([p[1] for p in points]))))

    rng = np.random.default_rng(7)
    freq_hetero = np.logspace(-2.2, 1.5, 30)
    hetero_tasks = []
    for _ in range(320):
        betas = rng.lognormal(mean=0.0, sigma=0.8, size=4)
        hetero_tasks.append(tuple(float(x) for x in betas))

    hetero_rows = parallel_map(hetero_cutoff_worker, [(betas, freq_hetero) for betas in hetero_tasks], chunksize=4)

    pulse_rows = []
    for n_step in (1, 2, 4, 8):
        t, y = simulate_chain_pulse(n_step)
        for ti, yi in zip(t, y):
            pulse_rows.append((n_step, ti, yi))

    save_npz(
        path,
        True,
        heat_rows=np.asarray(heat_rows, dtype=float),
        cutoff_rows=np.asarray(cutoff_rows, dtype=float),
        hetero_rows=np.asarray(hetero_rows, dtype=float),
        pulse_rows=np.asarray(pulse_rows, dtype=float),
    )


def ppi_steady_state(a_total: float, b_total: float, ka: float, kd: float) -> float:
    def rhs(_t, y):
        c = y[0]
        return [ka * (a_total - c) * (b_total - c) - kd * c]

    sol = solve_ivp(rhs, (0.0, 200.0), [0.0], rtol=RTOL, atol=ATOL, method="LSODA")
    if not sol.success:
        raise RuntimeError(sol.message)
    return float(sol.y[0, -1])


def ppi_validity_task(args):
    eps, wtau = args
    a_total = 2.0
    b_total = 2.0
    ka = 1.0
    kd = 1.0
    c_ss = ppi_steady_state(a_total, b_total, ka, kd)
    lam = ka * (a_total + b_total - 2.0 * c_ss) + kd
    tau = 1.0 / lam
    margin = min(c_ss, a_total - c_ss, b_total - c_ss)
    sensitivity = ka * (b_total - c_ss)
    amp = eps * lam * margin / sensitivity
    omega = wtau / tau
    cycles = cycles_for_frequency(omega, lam)
    theta_end = 2.0 * math.pi * cycles
    theta_eval = np.linspace(theta_end - 4.0 * math.pi, theta_end, 620)

    def full_rhs(phase, y):
        c = y[0]
        a_t = a_total + amp * math.sin(phase)
        return [(ka * (a_t - c) * (b_total - c) - kd * c) / omega]

    def local_rhs(phase, y):
        return [(-lam * y[0] + sensitivity * amp * math.sin(phase)) / omega]

    full = solve_ivp(full_rhs, (0.0, theta_end), [c_ss], t_eval=theta_eval, rtol=RTOL, atol=ATOL, method="LSODA")
    local = solve_ivp(local_rhs, (0.0, theta_end), [0.0], t_eval=theta_eval, rtol=RTOL, atol=ATOL, method="LSODA")
    if not full.success or not local.success:
        return eps, wtau, amp, omega, np.nan, np.nan, np.nan, np.nan
    full_y = full.y[0]
    local_y = c_ss + local.y[0]
    denom = np.sqrt(np.mean((full_y - c_ss) ** 2))
    err = np.sqrt(np.mean((full_y - local_y) ** 2)) / max(denom, 1e-12)
    a_t = a_total + amp * np.sin(full.t)
    boundary_distance = np.min(np.vstack([full_y, a_t - full_y, b_total - full_y])) / margin
    return eps, wtau, amp, omega, err, float(np.min(full_y)), float(np.max(full_y)), float(boundary_distance)


def ppi_validity_example(label: str, eps: float, wtau: float):
    a_total = 2.0
    b_total = 2.0
    ka = 1.0
    kd = 1.0
    c_ss = ppi_steady_state(a_total, b_total, ka, kd)
    lam = ka * (a_total + b_total - 2.0 * c_ss) + kd
    margin = min(c_ss, a_total - c_ss, b_total - c_ss)
    sensitivity = ka * (b_total - c_ss)
    amp = eps * lam * margin / sensitivity
    omega = wtau * lam
    cycles = cycles_for_frequency(omega, lam)
    theta_end = 2.0 * math.pi * cycles
    theta_eval = np.linspace(theta_end - 4.0 * math.pi, theta_end, 700)

    def full_rhs(phase, y):
        c = y[0]
        a_t = a_total + amp * math.sin(phase)
        return [(ka * (a_t - c) * (b_total - c) - kd * c) / omega]

    def local_rhs(phase, y):
        return [(-lam * y[0] + sensitivity * amp * math.sin(phase)) / omega]

    full = solve_ivp(full_rhs, (0.0, theta_end), [c_ss], t_eval=theta_eval, rtol=RTOL, atol=ATOL, method="LSODA")
    local = solve_ivp(local_rhs, (0.0, theta_end), [0.0], t_eval=theta_eval, rtol=RTOL, atol=ATOL, method="LSODA")
    cycles_rel = (theta_eval - theta_eval[0]) / (2.0 * math.pi)
    rows = []
    for cyc, yf, yl in zip(cycles_rel, full.y[0], c_ss + local.y[0]):
        if cyc <= 2.0:
            rows.append((label, eps, wtau, cyc, yf, yl))
    return rows


def generate_figure6(force: bool) -> None:
    path = DATA_DIR / "Fig6.npz"
    if should_skip(path, force):
        print(f"[data] skip existing {path.name}", flush=True)
        return

    eps_values = np.logspace(-2.0, -0.05, 81)
    wtau_values = np.logspace(-1.2, 1.0, 81)
    tasks = [(float(eps), float(wtau)) for eps in eps_values for wtau in wtau_values]
    map_rows = parallel_map(ppi_validity_task, tasks, chunksize=12)
    example_rows = []
    for label, eps, wtau in (("linear", 0.08, 0.7), ("moderate", 0.45, 1.0), ("nonlinear", 0.85, 1.8)):
        example_rows.extend(ppi_validity_example(label, eps, wtau))
    labels = {"linear": 0, "moderate": 1, "nonlinear": 2}
    example_numeric = [(labels[r[0]], *r[1:]) for r in example_rows]
    save_npz(
        path,
        True,
        map_rows=np.asarray(map_rows, dtype=float),
        example_rows=np.asarray(example_numeric, dtype=float),
        example_label_names=np.asarray(["linear", "moderate", "nonlinear"]),
    )


def variance_after_m_filters(m_filter: np.ndarray, beta: float = 1.0, noise_strength: float = 1.0) -> np.ndarray:
    m_filter = np.asarray(m_filter, dtype=float)
    log_coeff = [
        math.lgamma(float(m) - 0.5) - 0.5 * math.log(math.pi) - math.lgamma(float(m))
        for m in m_filter.ravel()
    ]
    coeff = np.exp(np.asarray(log_coeff, dtype=float)).reshape(m_filter.shape)
    return noise_strength * coeff / beta


def all_step_variance(n_step: np.ndarray, beta: float = 1.0, noise_strength: float = 1.0) -> np.ndarray:
    values = []
    for n in np.asarray(n_step, dtype=int):
        m = np.arange(1, n + 1, dtype=float)
        values.append(float(np.sum(variance_after_m_filters(m, beta=beta, noise_strength=noise_strength))))
    return np.asarray(values, dtype=float)


def total_variance_with_internal_noise(n_step: np.ndarray, q_internal: np.ndarray, beta: float = 1.0) -> np.ndarray:
    n_step = np.asarray(n_step, dtype=int)
    q_internal = np.asarray(q_internal, dtype=float)
    out = np.empty((len(q_internal), len(n_step)), dtype=float)
    for j, q in enumerate(q_internal):
        for i, n in enumerate(n_step):
            upstream = float(variance_after_m_filters(np.asarray([n]), beta=beta, noise_strength=1.0)[0])
            if n > 1:
                internal_m = np.arange(1, n, dtype=float)
                internal = float(np.sum(variance_after_m_filters(internal_m, beta=beta, noise_strength=q)))
            else:
                internal = 0.0
            out[j, i] = upstream + internal
    return out


def generate_figure5(force: bool) -> None:
    path = DATA_DIR / "Fig5.npz"
    if should_skip(path, force):
        print(f"[data] skip existing {path.name}", flush=True)
        return

    beta = 1.0
    n_step = np.arange(1, 65, dtype=int)
    cutoff = beta * np.sqrt(np.power(2.0, 1.0 / n_step) - 1.0)
    delay = n_step / beta
    upstream_var = variance_after_m_filters(n_step, beta=beta, noise_strength=1.0)
    all_step_var = all_step_variance(n_step, beta=beta, noise_strength=1.0)
    r_tot_values = np.logspace(-3.0, 1.0, 180)
    r_add_values = r_tot_values.copy()
    total_var = total_variance_with_internal_noise(n_step, r_add_values, beta=beta)
    baseline = float(upstream_var[0])
    log_ratio = np.log10(total_var / baseline)
    save_npz(
        path,
        True,
        n_step=n_step,
        r_tot_values=r_tot_values,
        r_add_values=r_add_values,
        cutoff=cutoff,
        delay=delay,
        upstream_var=upstream_var,
        all_step_var=all_step_var,
        total_var=total_var,
        log_ratio=log_ratio,
        baseline_variance=np.asarray([baseline], dtype=float),
    )


def cascade_jacobian(n_step: int, beta: float) -> np.ndarray:
    jac = np.zeros((n_step, n_step), dtype=float)
    for idx in range(n_step):
        jac[idx, idx] = -beta
        if idx > 0:
            jac[idx, idx - 1] = beta
    return jac


def source_transfer_gain(n_step: int, source_idx: int, omega: np.ndarray, beta: float) -> np.ndarray:
    distance = n_step - source_idx
    return beta ** max(distance - 1, 0) / (beta * beta + omega * omega) ** (0.5 * distance)


def source_variance_theory(n_step: int, source_idx: int, beta: float, noise_strength: float) -> float:
    jac = cascade_jacobian(n_step, beta)
    diffusion = np.zeros((n_step, n_step), dtype=float)
    diffusion[source_idx, source_idx] = 2.0 * noise_strength
    cov = solve_continuous_lyapunov(jac, -diffusion)
    return float(cov[-1, -1])


def simulate_stochastic_cascade(n_step: int, beta: float, noise_strengths: np.ndarray, seed: int) -> tuple[np.ndarray, float]:
    rng = np.random.default_rng(seed)
    dt = STOCHASTIC_DT
    burn = max(
        STOCHASTIC_BURN_STEPS,
        int(math.ceil(STOCHASTIC_RELAXATION_TIMES / (beta * dt))),
    )
    n_samples = STOCHASTIC_SAMPLES
    total_steps = burn + n_samples
    state = np.zeros(n_step, dtype=float)
    output = np.empty(n_samples, dtype=float)
    sqrt_noise = np.sqrt(2.0 * np.asarray(noise_strengths, dtype=float) * dt)

    for step in range(total_steps):
        drift = np.empty(n_step, dtype=float)
        drift[0] = -beta * state[0]
        if n_step > 1:
            drift[1:] = beta * (state[:-1] - state[1:])
        state += drift * dt + sqrt_noise * rng.normal(size=n_step)
        if step >= burn:
            output[step - burn] = state[-1]

    return output, dt


def binned_raw_spectrum(
    signal: np.ndarray,
    dt: float,
    n_bins: int = STOCHASTIC_BINS,
    log_bin_offset: float = 0.0,
) -> tuple[np.ndarray, np.ndarray]:
    """Return a raw one-sided spectrum on a shifted logarithmic bin grid."""
    nperseg = min(2**16, len(signal))
    freq, psd = welch(
        signal,
        fs=1.0 / dt,
        nperseg=nperseg,
        noverlap=nperseg // 2,
        detrend=False,
        scaling="density",
    )
    omega = 2.0 * math.pi * freq[1:]
    psd = psd[1:]
    valid = (omega > 0) & np.isfinite(omega)
    omega = omega[valid]
    psd = psd[valid]
    log_min = float(np.log(omega.min()))
    log_max = float(np.log(omega.max()))
    log_width = (log_max - log_min) / n_bins
    edges = np.exp(log_min + (np.arange(n_bins + 1) + float(log_bin_offset)) * log_width)
    centers = np.sqrt(edges[:-1] * edges[1:])
    binned = np.full(n_bins, np.nan)
    for idx in range(n_bins):
        mask = (omega >= edges[idx]) & (omega < edges[idx + 1]) & np.isfinite(psd)
        if np.any(mask):
            binned[idx] = float(np.mean(psd[mask]))
    return centers, binned


def beta_bin_offset(beta_index: int) -> float:
    """Return the reproducible beta-specific shift in log-bin-width units."""
    rng = np.random.default_rng(BETA_BIN_OFFSET_SEED + int(beta_index))
    return float(rng.uniform(-0.45, 0.45))


def grouped_spectrum_task(
    args: tuple[int, int, float, int, int, float],
) -> tuple[int, float, np.ndarray, np.ndarray]:
    group_id, n_step, beta, source_idx, seed, log_bin_offset = args
    strengths = np.zeros(n_step, dtype=float)
    strengths[source_idx] = 1.0
    signal, dt = simulate_stochastic_cascade(n_step, beta, strengths, seed=seed)
    omega, psd = binned_raw_spectrum(signal, dt, log_bin_offset=log_bin_offset)
    return group_id, float(np.var(signal)), omega, psd


def grouped_variance_task(args: tuple[int, int, float, int, int]) -> tuple[int, float]:
    group_id, n_step, beta, source_idx, seed = args
    strengths = np.zeros(n_step, dtype=float)
    strengths[source_idx] = 1.0
    signal, _ = simulate_stochastic_cascade(n_step, beta, strengths, seed=seed)
    return group_id, float(np.var(signal))


def accumulate_grouped_spectra(
    tasks,
    group_ids: np.ndarray,
    total_tasks: int,
    n_workers: int,
    label: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Average many spectra without retaining individual trajectories."""
    group_ids = np.asarray(group_ids, dtype=int)
    row_for_group = {int(group_id): row for row, group_id in enumerate(group_ids)}
    omega_by_group = np.full((len(group_ids), STOCHASTIC_BINS), np.nan, dtype=float)
    psd_sums = np.zeros((len(group_ids), STOCHASTIC_BINS), dtype=float)
    variance_sums = np.zeros(len(group_ids), dtype=float)
    variance_sums_of_squares = np.zeros(len(group_ids), dtype=float)
    counts = np.zeros(len(group_ids), dtype=np.int64)
    progress_every = max(1, min(1000, total_tasks))

    def consume(results) -> None:
        for completed, (group_id, variance, omega, psd) in enumerate(results, start=1):
            row = row_for_group[int(group_id)]
            if counts[row] == 0:
                omega_by_group[row] = omega
            elif not np.allclose(omega, omega_by_group[row], rtol=1e-12, atol=1e-14):
                raise RuntimeError(f"frequency grid changed within group {group_id}")
            psd_sums[row] += np.nan_to_num(psd, nan=0.0, posinf=0.0, neginf=0.0)
            variance_sums[row] += variance
            variance_sums_of_squares[row] += variance * variance
            counts[row] += 1
            if completed % progress_every == 0 or completed == total_tasks:
                print(f"[data] {label}: {completed}/{total_tasks} trajectories", flush=True)

    workers = min(max(int(n_workers), 1), total_tasks)
    if workers > 1:
        with Pool(processes=workers) as pool:
            consume(pool.imap(grouped_spectrum_task, tasks, chunksize=1))
    else:
        consume(map(grouped_spectrum_task, tasks))
    return omega_by_group, psd_sums, variance_sums, variance_sums_of_squares, counts


def accumulate_grouped_variances(
    tasks,
    group_ids: np.ndarray,
    total_tasks: int,
    n_workers: int,
    label: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    group_ids = np.asarray(group_ids, dtype=int)
    row_for_group = {int(group_id): row for row, group_id in enumerate(group_ids)}
    sums = np.zeros(len(group_ids), dtype=float)
    sums_of_squares = np.zeros(len(group_ids), dtype=float)
    counts = np.zeros(len(group_ids), dtype=np.int64)
    progress_every = max(1, min(1000, total_tasks))

    def consume(results) -> None:
        for completed, (group_id, variance) in enumerate(results, start=1):
            row = row_for_group[int(group_id)]
            sums[row] += variance
            sums_of_squares[row] += variance * variance
            counts[row] += 1
            if completed % progress_every == 0 or completed == total_tasks:
                print(f"[data] {label}: {completed}/{total_tasks} trajectories", flush=True)

    workers = min(max(int(n_workers), 1), total_tasks)
    if workers > 1:
        with Pool(processes=workers) as pool:
            consume(pool.imap(grouped_variance_task, tasks, chunksize=1))
    else:
        consume(map(grouped_variance_task, tasks))
    return sums, sums_of_squares, counts


def mean_and_sem(total: float, total_of_squares: float, count: int) -> tuple[float, float]:
    mean = total / count
    if count <= 1:
        return float(mean), 0.0
    sample_variance = (total_of_squares - total * total / count) / (count - 1)
    return float(mean), float(math.sqrt(max(sample_variance, 0.0) / count))


def generate_figure4(
    force: bool,
    source_replicates: int = 10000,
    fixed_m_beta_count: int = 1000,
    fixed_m_replicates: int = 1000,
    stochastic_workers: int = WORKERS,
) -> None:
    path = DATA_DIR / "Fig4.npz"
    if should_skip(path, force):
        print(f"[data] skip existing {path.name}", flush=True)
        return

    if source_replicates < 1 or fixed_m_beta_count < 1 or fixed_m_replicates < 1:
        raise ValueError("all Figure 4 sampling counts must be positive")
    if fixed_m_replicates > 10000:
        raise ValueError("fixed_m_replicates must not exceed 10000 with the published seed layout")

    beta = 1.0
    noise_strength = 1.0
    n_step = 5
    source_steps = (1, 3, 5)
    omega_dense = np.logspace(-2.0, 2.0, 260)
    spectrum_theory_rows = []
    spectrum_sim_rows = []
    variance_rows = [
        [step, source_variance_theory(n_step, step - 1, beta, noise_strength), np.nan, np.nan]
        for step in range(1, n_step + 1)
    ]

    for source_step in source_steps:
        m_filter = n_step - source_step + 1
        theory_shape = (1.0 + omega_dense**2) ** (-m_filter)
        spectrum_theory_rows.extend(
            (source_step, omega, value) for omega, value in zip(omega_dense, theory_shape)
        )

    panel_a_tasks = (
        (
            source_step,
            n_step,
            beta,
            source_step - 1,
            20261500 + 1_000_000 * (source_step - 1) + replicate,
            0.0,
        )
        for source_step in source_steps
        for replicate in range(source_replicates)
    )
    omega_by_source, psd_sums, var_sums, var_sums_sq, counts = accumulate_grouped_spectra(
        panel_a_tasks,
        np.asarray(source_steps, dtype=int),
        len(source_steps) * source_replicates,
        stochastic_workers,
        "Figure 4(a,b)",
    )
    for row, source_step in enumerate(source_steps):
        valid_bins = np.isfinite(omega_by_source[row]) & (psd_sums[row] > 0.0)
        normalized_psd = psd_sums[row, valid_bins] / counts[row] / (4.0 * noise_strength / beta**2)
        spectrum_sim_rows.extend(
            (source_step, omega, value)
            for omega, value in zip(omega_by_source[row, valid_bins], normalized_psd)
        )
        variance_rows[source_step - 1][2:] = mean_and_sem(var_sums[row], var_sums_sq[row], int(counts[row]))

    remaining_steps = (2, 4)
    panel_b_tasks = (
        (
            source_step,
            n_step,
            beta,
            source_step - 1,
            20262500 + 1_000_000 * (source_step - 1) + replicate,
        )
        for source_step in remaining_steps
        for replicate in range(source_replicates)
    )
    var_sums, var_sums_sq, counts = accumulate_grouped_variances(
        panel_b_tasks,
        np.asarray(remaining_steps, dtype=int),
        len(remaining_steps) * source_replicates,
        stochastic_workers,
        "Figure 4(b)",
    )
    for row, source_step in enumerate(remaining_steps):
        variance_rows[source_step - 1][2:] = mean_and_sem(var_sums[row], var_sums_sq[row], int(counts[row]))

    depth_rows = []
    for depth in range(1, 11):
        var_up_theory = source_variance_theory(depth, 0, beta, noise_strength)
        var_all_theory = sum(source_variance_theory(depth, idx, beta, noise_strength) for idx in range(depth))
        depth_rows.append((depth, var_up_theory, np.nan, var_all_theory, np.nan))

    beta_rng = np.random.default_rng(BETA_SAMPLE_SEED)
    beta_values = 10.0 ** beta_rng.uniform(-1.0, 1.0, fixed_m_beta_count)
    fixed_m_tasks = (
        (
            beta_index,
            n_step,
            float(sampled_beta),
            0,
            20270000 + beta_index * 10000 + replicate,
            beta_bin_offset(beta_index),
        )
        for beta_index, sampled_beta in enumerate(beta_values)
        for replicate in range(fixed_m_replicates)
    )
    omega_by_beta, psd_sums, _var_sums, _var_sums_sq, counts = accumulate_grouped_spectra(
        fixed_m_tasks,
        np.arange(fixed_m_beta_count, dtype=int),
        fixed_m_beta_count * fixed_m_replicates,
        stochastic_workers,
        "Figure 4(d,e)",
    )
    fixed_m_sim_rows = []
    for beta_index, sampled_beta in enumerate(beta_values):
        valid_bins = np.isfinite(omega_by_beta[beta_index]) & (psd_sums[beta_index] > 0.0)
        omega = omega_by_beta[beta_index, valid_bins]
        normalized_psd = psd_sums[beta_index, valid_bins] / counts[beta_index] / (4.0 / sampled_beta**2)
        fixed_m_sim_rows.extend(
            (n_step, sampled_beta, 1.0 / sampled_beta, value_omega, value_omega / sampled_beta, value)
            for value_omega, value in zip(omega, normalized_psd)
        )

    save_npz(
        path,
        True,
        spectrum_theory_rows=np.asarray(spectrum_theory_rows, dtype=float),
        spectrum_sim_rows=np.asarray(spectrum_sim_rows, dtype=float),
        variance_rows=np.asarray(variance_rows, dtype=float),
        depth_rows=np.asarray(depth_rows, dtype=float),
        fixed_m_sim_rows=np.asarray(fixed_m_sim_rows, dtype=float),
        beta_values=np.asarray(beta_values, dtype=float),
        beta_bin_offsets=np.asarray([beta_bin_offset(index) for index in range(fixed_m_beta_count)], dtype=float),
        stochastic_dt=np.asarray([STOCHASTIC_DT], dtype=float),
        spectrum_replicates=np.asarray([source_replicates], dtype=int),
        variance_replicates=np.asarray([source_replicates], dtype=int),
        fixed_m_replicates=np.asarray([fixed_m_replicates], dtype=int),
    )


GENERATORS = {
    "1": generate_figure1,
    "2": generate_figure2,
    "3": generate_figure3,
    "4": generate_figure4,
    "5": generate_figure5,
    "6": generate_figure6,
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true", help="regenerate existing data files")
    parser.add_argument("--figures", nargs="*", choices=sorted(GENERATORS), default=sorted(GENERATORS))
    parser.add_argument(
        "--source-replicates",
        "--stochastic-replicates",
        dest="source_replicates",
        type=int,
        default=10000,
        help="trajectories per noise-source step in Fig. 4(a,b)",
    )
    parser.add_argument("--fixed-m-beta-count", type=int, default=1000, help="beta values in Fig. 4(d,e)")
    parser.add_argument("--fixed-m-replicates", type=int, default=1000, help="trajectories per beta in Fig. 4(d,e)")
    parser.add_argument(
        "--stochastic-workers",
        type=int,
        default=WORKERS,
        help="local worker processes used on this server",
    )
    args = parser.parse_args()

    ensure_dirs()
    for fig in args.figures:
        print(f"[data] Fig. {fig}", flush=True)
        if fig == "4":
            generate_figure4(
                args.force,
                source_replicates=args.source_replicates,
                fixed_m_beta_count=args.fixed_m_beta_count,
                fixed_m_replicates=args.fixed_m_replicates,
                stochastic_workers=args.stochastic_workers,
            )
        else:
            GENERATORS[fig](args.force)


if __name__ == "__main__":
    main()
