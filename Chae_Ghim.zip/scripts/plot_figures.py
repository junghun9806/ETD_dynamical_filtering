#!/usr/bin/env python3
"""Reproduce the six figures in the main text from saved numerical data."""

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.lines import Line2D
from matplotlib.colors import LogNorm, TwoSlopeNorm
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import numpy as np

from figure_style import PALETTE, apply_style, finish_axes, style_colorbar


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "figures"


def ensure_dirs() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)


def load(name: str):
    path = DATA_DIR / name
    if not path.exists():
        raise FileNotFoundError(f"missing figure data: {path}")
    return np.load(path)


def save(fig, name: str) -> None:
    """Write a 600-dpi PNG figure."""
    fig.savefig(OUT_DIR / f"{name}.png", dpi=600)
    plt.close(fig)


def plot_figure1() -> None:
    """Plot main-text Fig. 1 from the reversible-binding and cascade data."""
    data = load("Fig1.npz")
    fig = plt.figure(figsize=(4.20, 5.25), constrained_layout=True)
    fig.set_constrained_layout_pads(h_pad=0.0, hspace=0.0)
    gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 1.0, 1.0])
    axes = np.asarray(
        [
            fig.add_subplot(gs[0, 0]),
            fig.add_subplot(gs[0, 1]),
            fig.add_subplot(gs[1, 0]),
            fig.add_subplot(gs[1, 1]),
            fig.add_subplot(gs[2, 0]),
            fig.add_subplot(gs[2, 1]),
        ],
        dtype=object,
    )
    label_size = 8
    legend_size = 6
    axes[0].set_box_aspect(1.0)

    ax = axes[0]
    tau = data["tau"]
    relaxation_time = data["relaxation_time"]
    forcing_fraction = data["perturbation_fraction"]
    lim = [min(tau.min(), relaxation_time.min()), max(tau.max(), relaxation_time.max())]
    ax.loglog(lim, lim, color="black", lw=1.6, zorder=1)
    parameter_scatter = ax.scatter(
        tau,
        relaxation_time,
        c=forcing_fraction,
        s=5,
        cmap="magma",
        vmin=0.0,
        vmax=0.5,
        alpha=0.18,
        linewidths=0,
        zorder=3,
    )
    ax.set_xlabel(r"$\tau$ (h)")
    ax.set_ylabel("Relaxation time (h)")
    decade_ticks = 10.0 ** np.arange(-3, 1)
    ax.set_xticks(decade_ticks)
    ax.set_yticks(decade_ticks)
    ax.xaxis.set_major_formatter(mticker.LogFormatterMathtext(base=10))
    ax.yaxis.set_major_formatter(mticker.LogFormatterMathtext(base=10))
    minor_subs = np.arange(2, 10) * 0.1
    ax.xaxis.set_minor_locator(mticker.LogLocator(base=10, subs=minor_subs, numticks=100))
    ax.yaxis.set_minor_locator(mticker.LogLocator(base=10, subs=minor_subs, numticks=100))
    ax.xaxis.set_minor_formatter(mticker.NullFormatter())
    ax.yaxis.set_minor_formatter(mticker.NullFormatter())
    cbar = fig.colorbar(parameter_scatter, ax=ax, label="Forcing fraction", fraction=0.07, pad=0.01)
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 8

    ax = axes[1]
    gain = data["collapse_gain"]
    omega_tau = data["collapse_omega_tau"]
    valid = np.isfinite(gain) & (gain > 0) & np.isfinite(omega_tau) & (omega_tau > 0)
    ax.semilogx(data["local_line_x"], data["local_line_gain"], color="black", lw=2.0, zorder=1)
    ax.scatter(
        omega_tau[valid],
        gain[valid],
        color="0.35",
        s=5,
        alpha=0.18,
        linewidths=0,
        zorder=3,
    )
    ax.set_xlabel(r"$\omega\tau$")
    ax.set_ylabel(r"$G$")
    ax.set_ylim(0, 1.02)

    ax = axes[2]
    response_colors = {"mRNA": PALETTE["orange"], "Protein": PALETTE["blue"]}
    normalized_frequency = data["panel_b_x"]
    ax.semilogx(
        normalized_frequency,
        data["panel_b_m_gain"],
        color=response_colors["mRNA"],
        label=r"mRNA: $\omega/\beta_m$",
        zorder=2,
    )
    ax.scatter(
        normalized_frequency[::4],
        data["panel_b_m_gain"][::4],
        color=response_colors["mRNA"],
        s=8,
        zorder=3,
    )
    ax.semilogx(
        normalized_frequency,
        data["panel_b_p_gain"],
        color=response_colors["Protein"],
        label=r"Protein: $\omega\tau$",
        zorder=4,
    )
    ax.scatter(
        normalized_frequency[::4],
        data["panel_b_p_gain"][::4],
        color=response_colors["Protein"],
        s=8,
        zorder=5,
    )
    ax.set_xlabel("Normalized frequency")
    ax.set_ylabel(r"$G$")
    ax.legend(frameon=False, loc="upper right", bbox_to_anchor=(1.03, 1.0), handlelength=1.2)
    ax.set_ylim(0, 1.02)

    ax = axes[3]
    cascade_rows = data["cascade_rows"]
    stage_colors = ["0.00", "0.25", "0.40", "0.55", "0.70"]
    for n_step in range(1, 6):
        points = cascade_rows[cascade_rows[:, 0] == n_step]
        ax.loglog(points[:, 1], points[:, 3], color=stage_colors[n_step - 1], lw=1.05, label=fr"$x_{n_step}$")
    points = cascade_rows[cascade_rows[:, 0] == 10]
    ax.loglog(points[:, 1], points[:, 3], color=stage_colors[-1], lw=1.05, ls="--", label=r"$x_{10}$")
    ax.set_xlabel(r"$\omega\tau$")
    ax.set_ylabel(r"$G$")
    ax.set_xlim(1e-1, 1e2)
    ax.set_ylim(1e-6, 1.0)
    ax.legend(frameon=False, loc="lower left", handlelength=1.2)

    delay_rows = data["delay_rows"]
    depth_colors = [PALETTE["blue"], PALETTE["orange"], PALETTE["green"], PALETTE["purple"]]
    delay_styles = {
        1: (0, (1.0, 1.0)),
        2: (0, (2.0, 1.0)),
        4: (0, (3.0, 1.2, 1.0, 1.2)),
        8: "solid",
    }
    marker_offsets = {1: 0, 2: 2, 4: 4, 8: 6}

    ax = axes[4]
    for n_step, color in zip((1, 2, 4, 8), depth_colors):
        points = delay_rows[delay_rows[:, 0] == n_step]
        ax.semilogx(points[:, 1], points[:, 2], color=color, lw=1.0, ls=delay_styles[n_step], label=f"n={n_step}")
        ax.scatter(
            points[marker_offsets[n_step] :: 10, 1],
            points[marker_offsets[n_step] :: 10, 2],
            s=9,
            facecolors="white",
            edgecolors=color,
            linewidths=0.75,
        )
    ax.set_xlabel(r"$\omega/\beta$")
    ax.set_ylabel(r"$\tau_{\rm p}/\tau_0$")
    ax.set_xlim(10**-1.2, 10**1.2)
    ax.set_ylim(0, 1.02)
    ax.legend(frameon=False, loc="lower left", handlelength=1.2)

    ax = axes[5]
    for n_step, color in zip((1, 2, 4, 8), depth_colors):
        points = delay_rows[delay_rows[:, 0] == n_step]
        ax.semilogx(points[:, 1], points[:, 3], color=color, lw=1.0, ls=delay_styles[n_step])
        ax.scatter(
            points[marker_offsets[n_step] :: 10, 1],
            points[marker_offsets[n_step] :: 10, 3],
            s=9,
            facecolors="white",
            edgecolors=color,
            linewidths=0.75,
        )
    ax.set_xlabel(r"$\omega/\beta$")
    ax.set_ylabel(r"$\tau_{\rm g}/\tau_0$")
    ax.set_xlim(10**-1.2, 10**1.2)
    ax.set_ylim(0, 1.02)

    for ax in axes:
        ax.xaxis.label.set_size(label_size)
        ax.yaxis.label.set_size(label_size)
        ax.yaxis.labelpad = 1.5
        legend = ax.get_legend()
        if legend is not None:
            for text in legend.get_texts():
                text.set_fontsize(legend_size)
            legend.get_title().set_fontsize(legend_size)
    finish_axes(axes, labels=["(a)", "(b)", "(c)", "(d)", "(e)", "(f)"])

    save(fig, "Fig1")


def plot_figure2() -> None:
    data = load("Fig2.npz")
    fig, axes = plt.subplots(1, 3, figsize=(7.25, 2.45), constrained_layout=False)
    fig.subplots_adjust(left=0.075, right=0.985, bottom=0.22, top=0.88, wspace=0.34)
    steady = data["steady_rows"]
    metric = data["metric_rows"]
    gain = data["gain_rows"]
    transfer = data["transfer_rows"] if "transfer_rows" in data.files else None

    theta = steady[:, 0]
    p_ss = steady[:, 2]
    loop = steady[:, 3]
    axes[0].plot(theta, p_ss, lw=1.4, color=PALETTE["blue"], label=r"$p_{ss}$")
    axes[0].plot(theta, loop / max(loop.max(), 1e-12), lw=1.4, color=PALETTE["red"], label=r"$\lambda$")
    axes[0].set_xlabel(r"Feedback strength, $\theta$")
    axes[0].set_ylabel("Normalized steady state / gain")
    axes[0].legend(frameon=False)

    gray_levels = {0.0: "0.70", 0.5: "0.55", 1.0: "0.42", 5.0: "0.27", 10.0: "0.08"}
    reference_delay = metric[np.argmin(np.abs(metric[:, 0])), 3]
    for theta_value, color in gray_levels.items():
        if transfer is not None:
            pts_transfer = transfer[np.isclose(transfer[:, 0], theta_value)]
            axes[1].semilogx(
                pts_transfer[:, 1] * reference_delay,
                pts_transfer[:, 2],
                color=color,
                lw=1.2,
                label=fr"$\theta={theta_value:g}$",
            )
        else:
            pts = gain[np.isclose(gain[:, 0], theta_value)]
            axes[1].semilogx(
                pts[:, 1] * reference_delay,
                pts[:, 2],
                color=color,
                lw=1.2,
                label=fr"$\theta={theta_value:g}$",
            )
        pts_ode = gain[np.isclose(gain[:, 0], theta_value)]
        axes[1].scatter(
            pts_ode[::5, 1] * reference_delay,
            pts_ode[::5, 2],
            s=10,
            facecolors="white",
            edgecolors=color,
            linewidths=0.8,
            zorder=3,
        )
    axes[1].set_xlabel(r"Normalized frequency, $\omega\tau(0)$")
    axes[1].set_ylabel("Normalized gain")
    axes[1].legend(frameon=False, fontsize=6)

    delay = metric[:, 3]
    cutoff = metric[:, 4]
    axes[2].plot(metric[:, 0], delay / delay[0], lw=1.4, color=PALETTE["blue"], label=r"Low-frequency delay")
    axes[2].plot(metric[:, 0], cutoff / cutoff[0], lw=1.4, color=PALETTE["orange"], label=r"Cutoff frequency")
    axes[2].set_xlabel(r"Feedback strength, $\theta$")
    axes[2].set_ylabel("Normalized delay / cutoff frequency")
    axes[2].legend(frameon=False, loc="center right")
    finish_axes(axes, labels=["(a)", "(b)", "(c)"])
    save(fig, "Fig2")


def plot_figure3() -> None:
    data = load("Fig3.npz")
    fig, axes = plt.subplots(2, 2, figsize=(3.45, 3.20), constrained_layout=True)
    fig.set_constrained_layout_pads(wspace=0.15)
    heat = data["heat_rows"]
    omega_vals = np.asarray(sorted(set(heat[:, 1])))
    n_vals = np.asarray(sorted(set(heat[:, 0]))).astype(int)
    z = np.array([[heat[(heat[:, 0] == n) & np.isclose(heat[:, 1], omega), 2][0] for omega in omega_vals] for n in n_vals])
    mesh = axes[0, 0].pcolormesh(
        omega_vals,
        n_vals,
        z,
        shading="auto",
        cmap="viridis",
        vmin=0,
        vmax=1,
        linewidth=0,
        edgecolors="none",
        antialiased=False,
    )
    axes[0, 0].set_xscale("log")
    axes[0, 0].set_xlabel(r"Frequency, $\omega$ (h$^{-1}$)")
    axes[0, 0].set_ylabel(r"Cascade depth, $n$")
    axes[0, 0].yaxis.labelpad = 2
    cbar = fig.colorbar(mesh, ax=axes[0, 0], label=r"Normalized gain, $G$")
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 8

    cutoff = data["cutoff_rows"]
    axes[0, 1].plot(cutoff[:, 0], cutoff[:, 1], "-", lw=1.1, color=PALETTE["blue"], label="measured cutoff")
    axes[0, 1].scatter(cutoff[:, 0], cutoff[:, 1], s=9, color=PALETTE["blue"], zorder=3)
    axes[0, 1].set_xlabel(r"Cascade depth, $n$")
    axes[0, 1].set_ylabel(r"Cutoff frequency, $\omega_c$ (h$^{-1}$)")
    axes[0, 1].yaxis.labelpad = 3
    axes[0, 1].set_xticks([2, 4, 6, 8, 10])
    y_top = float(np.nanmax(cutoff[:, 1]))
    axes[0, 1].set_ylim(-0.05 * y_top, 1.05 * y_top)
    axes[0, 1].legend(frameon=False)

    hetero = data["hetero_rows"]
    sc = axes[1, 0].scatter(
        hetero[:, 0],
        hetero[:, 1],
        c=hetero[:, 2],
        s=5,
        cmap="magma",
        vmin=0.2,
        vmax=0.8,
        alpha=0.62,
        linewidths=0,
    )
    axes[1, 0].set_xscale("log")
    axes[1, 0].set_yscale("log")
    axes[1, 0].set_xlabel(r"Total delay, $\tau_0$ (h)")
    axes[1, 0].set_ylabel(r"Cutoff frequency, $\omega_c$ (h$^{-1}$)")
    axes[1, 0].yaxis.labelpad = 2
    cbar = fig.colorbar(sc, ax=axes[1, 0], label="Slowest delay fraction")
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 8
    pulse = data["pulse_rows"]
    max_y = float(np.max(pulse[:, 2]))
    for n_step, color in zip((1, 2, 4, 8), (PALETTE["blue"], PALETTE["orange"], PALETTE["green"], PALETTE["purple"])):
        pts = pulse[pulse[:, 0] == n_step]
        axes[1, 1].plot(pts[:, 1], pts[:, 2] / max_y, color=color, label=f"n={n_step}")
    axes[1, 1].set_xlabel(r"Time, $t$ (h)")
    axes[1, 1].set_ylabel("Normalized response")
    axes[1, 1].yaxis.labelpad = 3
    axes[1, 1].legend(frameon=False)
    for ax in axes.ravel():
        ax.xaxis.labelpad = 2
    finish_axes(axes, labels=["(a)", "(b)", "(c)", "(d)"])
    save(fig, "Fig3")


def plot_figure5() -> None:
    """Plot main-text Fig. 5 in its single-column 2-by-2 layout."""
    data = load("Fig5.npz")
    n_step = data["n_step"]
    cutoff = data["cutoff"]
    delay = data["delay"]
    upstream_var = data["upstream_var"]
    all_step_var = data["all_step_var"]
    r_values = data["r_values"] if "r_values" in data.files else data["q_values"]
    all_step_log_ratio = data["log_ratio"]
    baseline_variance = float(data["baseline_variance"][0])

    fig, axes_grid = plt.subplots(2, 2, figsize=(3.80, 3.80), constrained_layout=False)
    fig.subplots_adjust(left=0.150, right=0.860, bottom=0.105, top=0.955, wspace=0.58, hspace=0.74)
    axes = axes_grid.ravel()

    axes[0].plot(n_step, delay, color=PALETTE["blue"], lw=1.4)
    axes[0].set_xlabel(r"Cascade depth, $n$")
    axes[0].set_ylabel(r"Mean delay, $n/\beta$", color=PALETTE["blue"])
    axes[0].tick_params(axis="y", colors=PALETTE["blue"])
    left_bottom = -0.05 * (float(delay.max()) - float(delay.min()))
    left_top = float(delay.max()) + 0.05 * (float(delay.max()) - float(delay.min()))
    axes[0].set_ylim(left_bottom, left_top)

    ax_cut = axes[0].twinx()
    ax_cut.plot(n_step, cutoff, color=PALETTE["red"], lw=1.4)
    ax_cut.set_ylabel(
        r"Bandwidth, $\omega_{\mathrm{c}}/\beta$",
        color=PALETTE["red"],
        rotation=270,
        labelpad=5,
    )
    zero_fraction = (0.0 - left_bottom) / (left_top - left_bottom)
    right_top = 1.05 * float(cutoff.max())
    right_bottom = -zero_fraction * right_top / (1.0 - zero_fraction)
    ax_cut.set_ylim(right_bottom, right_top)
    ax_cut.tick_params(axis="y", colors=PALETTE["red"], direction="in", width=0.85, length=3.1, labelsize=6)
    for spine in ax_cut.spines.values():
        spine.set_linewidth(0.9)

    shared_fixed_total_var = all_step_var / n_step
    noise_colors = {"upstream": "#0072B2", "shared": "#009E73", "all_step": "#D55E00"}
    axes[1].loglog(cutoff, upstream_var / cutoff, color=noise_colors["upstream"], lw=1.2)
    axes[1].loglog(cutoff, shared_fixed_total_var / cutoff, color=noise_colors["shared"], lw=1.2)
    axes[1].loglog(cutoff, all_step_var / cutoff, color=noise_colors["all_step"], lw=1.2)
    for n in (1, 4, 16, 64):
        idx = int(n - 1)
        axes[1].scatter(cutoff[idx], upstream_var[idx] / cutoff[idx], s=14, marker="o", color=noise_colors["upstream"], zorder=3)
        axes[1].scatter(cutoff[idx], shared_fixed_total_var[idx] / cutoff[idx], s=13, marker="s", color=noise_colors["shared"], zorder=3)
        axes[1].scatter(cutoff[idx], all_step_var[idx] / cutoff[idx], s=15, marker="^", color=noise_colors["all_step"], zorder=3)
    axes[1].invert_xaxis()
    axes[1].set_xlabel(r"Bandwidth, $\omega_{\mathrm{c}}/\beta$")
    axes[1].set_ylabel(r"Variance per bandwidth, $\beta\sigma^2/\omega_{\mathrm{c}}$")
    noise_handles = [
        Line2D([0], [0], color=noise_colors["upstream"], marker="o", lw=1.2, ms=3.2, label="Upstream"),
        Line2D([0], [0], color=noise_colors["shared"], marker="s", lw=1.2, ms=3.2, label="Shared"),
        Line2D([0], [0], color=noise_colors["all_step"], marker="^", lw=1.2, ms=3.4, label="All-step"),
    ]
    axes[1].legend(handles=noise_handles, frameon=False, fontsize=6, loc="upper left")
    for n in (1, 4, 16, 64):
        idx = int(n - 1)
        axes[1].plot(
            [cutoff[idx], cutoff[idx]],
            [1.0, 0.975],
            transform=axes[1].get_xaxis_transform(),
            color="0.35",
            lw=0.6,
            clip_on=False,
        )
        label_anchor = (cutoff[idx], 1.025)
        for text_value, offset, alignment in (
            (r"$n$", -3.0, "right"),
            (r"$=$", 0.0, "center"),
            (fr"${n}$", 3.0, "left"),
        ):
            axes[1].annotate(
                text_value,
                xy=label_anchor,
                xycoords=axes[1].get_xaxis_transform(),
                xytext=(offset, 0.0),
                textcoords="offset points",
                ha=alignment,
                va="bottom",
                fontsize=5.5,
                annotation_clip=False,
            )

    shared_total_var = np.broadcast_to(upstream_var, (len(r_values), len(n_step))).copy()
    internal_unit_var = all_step_var - upstream_var
    shared_total_var[:, 1:] += r_values[:, None] * internal_unit_var[None, 1:] / (n_step[None, 1:] - 1.0)
    shared_log_ratio = np.log10(shared_total_var / baseline_variance)
    mesh_shared = axes[2].pcolormesh(
        n_step,
        r_values,
        shared_log_ratio,
        shading="auto",
        cmap="coolwarm",
        norm=TwoSlopeNorm(vmin=-1.0, vcenter=0.0, vmax=1.0),
        linewidth=0,
        edgecolors="none",
        antialiased=False,
    )
    axes[2].contour(n_step, r_values, shared_log_ratio, levels=[0.0], colors="black", linewidths=1.0)
    axes[2].set_yscale("log")
    axes[2].set_xlabel(r"Cascade depth, $n$")
    axes[2].set_ylabel(r"Noise ratio, $r$")
    axes[2].set_xlim(1, 64)
    axes[2].set_title("Shared", fontsize=7, pad=3)

    mesh_all_step = axes[3].pcolormesh(
        n_step,
        r_values,
        all_step_log_ratio,
        shading="auto",
        cmap="coolwarm",
        norm=TwoSlopeNorm(vmin=-1.0, vcenter=0.0, vmax=1.0),
        linewidth=0,
        edgecolors="none",
        antialiased=False,
    )
    axes[3].contour(n_step, r_values, all_step_log_ratio, levels=[0.0], colors="black", linewidths=1.0)
    axes[3].set_yscale("log")
    axes[3].set_xlabel(r"Cascade depth, $n$")
    axes[3].set_ylabel(r"Noise ratio, $r$")
    axes[3].set_xlim(1, 64)
    axes[3].set_title("All-step", fontsize=7, pad=3)

    cax = inset_axes(
        axes[3],
        width="7%",
        height="100%",
        loc="lower left",
        bbox_to_anchor=(1.03, 0.0, 1.0, 1.0),
        bbox_transform=axes[3].transAxes,
        borderpad=0,
    )
    cbar = fig.colorbar(mesh_all_step, cax=cax, label=r"Relative output variance, $\sigma^2/\sigma_1^2$")
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.set_ticks([-1.0, 0.0, 1.0])
    cbar.set_ticklabels([r"$10^{-1}$", r"$10^{0}$", r"$10^{1}$"])
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 5

    for ax in axes:
        ax.xaxis.labelpad = 2
        ax.yaxis.labelpad = 2
    finish_axes(axes, labels=["(a)", "(b)", "(c)", "(d)"])
    save(fig, "Fig5")


def plot_figure4() -> None:
    data = load("Fig4.npz")
    fig, axes = plt.subplots(3, 2, figsize=(3.45, 4.55), constrained_layout=False)
    fig.subplots_adjust(left=0.145, right=0.945, bottom=0.10, top=0.955, wspace=0.48, hspace=0.62)
    axes = axes.ravel()
    colors = {1: PALETTE["blue"], 3: PALETTE["orange"], 5: PALETTE["red"]}

    theory = data["spectrum_theory_rows"]
    sim = data["spectrum_sim_rows"]
    for source, color in colors.items():
        pts = theory[theory[:, 0] == source]
        pts = pts[(pts[:, 1] >= 1e-2) & (pts[:, 1] <= 10.0)]
        axes[0].loglog(pts[:, 1], pts[:, 2], color=color, lw=1.1, label=fr"Step {source}")
        pts_sim = sim[sim[:, 0] == source]
        pts_sim = pts_sim[(pts_sim[:, 1] >= 1e-2) & (pts_sim[:, 1] <= 10.0)]
        axes[0].scatter(pts_sim[::4, 1], pts_sim[::4, 2], s=9, facecolors="white", edgecolors=color, linewidths=0.65)
    axes[0].set_xlabel(r"Frequency, $\omega$ (h$^{-1}$)")
    axes[0].set_ylabel("Normalized output spectrum")
    axes[0].set_xlim(1e-2, 10.0)
    axes[0].set_ylim(1e-10, 1.5)
    axes[0].legend(frameon=False, title="Noise source", fontsize=6, title_fontsize=6)

    variance = data["variance_rows"]
    theory_var = variance[:, 1]
    sim_var = variance[:, 2]
    sim_sem = variance[:, 3] if variance.shape[1] > 3 else np.zeros_like(sim_var)
    theory_fraction = theory_var / np.sum(theory_var)
    valid = np.isfinite(sim_var)
    axes[1].plot(
        variance[:, 0],
        theory_fraction,
        "-o",
        color="black",
        lw=1.0,
        ms=3.0,
        label="theory",
        zorder=2,
    )
    axes[1].errorbar(
        variance[valid, 0],
        sim_var[valid] / np.sum(theory_var),
        yerr=sim_sem[valid] / np.sum(theory_var),
        fmt="o",
        ms=3.6,
        color=PALETTE["red"],
        ecolor=PALETTE["red"],
        elinewidth=0.8,
        capsize=1.8,
        zorder=3,
        label="simulation",
    )
    axes[1].set_xlabel(r"Noise-source step, $i$")
    axes[1].set_ylabel("Output variance fraction")
    axes[1].set_xticks(variance[:, 0])
    axes[1].legend(frameon=False, fontsize=6)

    depth = data["depth_rows"]
    norm = max(depth[0, 1], 1e-14)
    depth_n = depth[:, 0]
    cutoff = np.sqrt(np.power(2.0, 1.0 / depth_n) - 1.0)
    all_var = depth[:, 3] / norm
    up_var = depth[:, 1] / norm
    axes[2].loglog(cutoff, all_var, color=PALETTE["purple"], marker="o", ms=2.6, lw=1.0, label="all-step")
    axes[2].loglog(cutoff, up_var, color=PALETTE["blue"], marker="o", ms=2.6, lw=1.0, label="upstream")
    axes[2].set_xlabel(r"Normalized cutoff, $\omega_c/\beta$")
    axes[2].set_ylabel("Normalized output variance")
    axes[2].set_xlim(1.05, 0.2)
    axes[2].set_xticks([1.0, 0.3, 0.2])
    axes[2].set_xticklabels(["1", "0.3", "0.2"])
    axes[2].xaxis.set_minor_formatter(mticker.NullFormatter())
    axes[2].set_ylim(min(np.min(up_var), np.min(all_var)) * 0.75, max(np.max(up_var), np.max(all_var)) * 1.35)
    axes[2].legend(frameon=False, fontsize=6)

    collapse = data["collapse_rows"]
    m_colors = {
        1: PALETTE["red"],
        2: PALETTE["orange"],
        3: PALETTE["green"],
        4: PALETTE["cyan"],
        5: PALETTE["blue"],
    }

    fixed_m = collapse[collapse[:, 0] == 5]
    sc = axes[3].scatter(
        fixed_m[:, 2],
        fixed_m[:, 5],
        c=fixed_m[:, 4],
        s=5,
        cmap="viridis",
        norm=LogNorm(vmin=float(np.nanmin(fixed_m[:, 4])), vmax=float(np.nanmax(fixed_m[:, 4]))),
        alpha=0.17,
        linewidths=0,
    )
    axes[3].set_xscale("log")
    axes[3].set_yscale("log")
    axes[3].set_ylim(1e-10, 1.0)
    axes[3].set_xlabel(r"Delay, $\tau$ (h)")
    axes[3].set_ylabel("Normalized spectrum")
    cbar = fig.colorbar(sc, ax=axes[3], label=r"Normalized frequency, $\omega\tau$", fraction=0.060, pad=0.050)
    cbar.solids.set_edgecolor("face")
    style_colorbar(cbar)
    cbar.set_ticks([1e-2, 1e0, 1e2])
    cbar.set_ticklabels([r"$10^{-2}$", r"$10^0$", r"$10^2$"])
    cbar.ax.yaxis.set_ticks_position("right")
    cbar.ax.yaxis.set_label_position("right")
    cbar.ax.yaxis.label.set_rotation(270)
    cbar.ax.yaxis.labelpad = 6
    cbar.ax.tick_params(pad=1.0)

    x_line = np.logspace(-2.0, 2.0, 260)
    axes[4].scatter(
        fixed_m[:, 4],
        fixed_m[:, 5],
        color="0.45",
        s=5,
        alpha=0.15,
        linewidths=0,
    )
    axes[4].loglog(x_line, (1.0 + x_line * x_line) ** (-5), color="black", lw=1.0)
    axes[4].set_xlabel(r"Normalized frequency, $\omega\tau$")
    axes[4].set_ylabel("Normalized spectrum")
    axes[4].set_ylim(1e-10, 1.0)

    axins = inset_axes(axes[4], width="44%", height="38%", loc="lower left", borderpad=0.75)
    axins.scatter(
        fixed_m[:, 4],
        fixed_m[:, 5],
        color="0.45",
        s=3,
        alpha=0.14,
        linewidths=0,
    )
    axins.plot(x_line, (1.0 + x_line * x_line) ** (-5), color="black", lw=0.8)
    axins.set_xscale("log")
    axins.set_xlim(1e-2, 1e2)
    axins.set_ylim(0.0, 1.0)
    axins.set_xticks([1e-2, 1e2])
    axins.set_xticklabels([r"$10^{-2}$", r"$10^2$"])
    axins.set_yticks([0.0, 1.0])
    axins.tick_params(direction="in", width=0.5, length=2.0, labelsize=5, pad=1)
    for spine in axins.spines.values():
        spine.set_linewidth(0.55)
    axins.set_facecolor("white")

    for m_filter, color in m_colors.items():
        marker_x = np.logspace(-2.0, 2.0, 18)
        marker_y = (1.0 + marker_x * marker_x) ** (-m_filter)
        axes[5].scatter(marker_x, marker_y, s=9, facecolors="white", edgecolors=color, linewidths=0.65)
        axes[5].loglog(x_line, (1.0 + x_line * x_line) ** (-m_filter), color=color, lw=1.0, label=fr"$m={m_filter}$")
    axes[5].set_xlabel(r"Normalized frequency, $\omega\tau$")
    axes[5].set_ylabel("Normalized spectrum")
    axes[5].set_ylim(1e-10, 1.5)
    axes[5].legend(frameon=False, fontsize=6, handlelength=1.4, loc="lower left")

    for ax in axes:
        ax.xaxis.labelpad = 2
        ax.yaxis.labelpad = 1

    finish_axes(axes, labels=["(a)", "(b)", "(c)", "(d)", "(e)", "(f)"])
    save(fig, "Fig4")


def plot_figure6() -> None:
    data = load("Fig6.npz")
    rows = data["map_rows"]
    eps_values = np.asarray(sorted(set(rows[:, 0])))
    wtau_values = np.asarray(sorted(set(rows[:, 1])))
    z = rows[:, 4].reshape(len(eps_values), len(wtau_values))
    boundary = rows[:, 7].reshape(len(eps_values), len(wtau_values))
    boundary_approach = 1.0 - boundary

    fig = plt.figure(figsize=(7.25, 2.05), constrained_layout=False)
    gs = fig.add_gridspec(
        1,
        5,
        width_ratios=[0.98, 0.045, 0.98, 0.045, 1.35],
        left=0.055,
        right=0.99,
        bottom=0.21,
        top=0.87,
        wspace=0.46,
    )
    axes = np.asarray([fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[0, 2]), fig.add_subplot(gs[0, 4])], dtype=object)
    cbar_axes = [fig.add_subplot(gs[0, 1]), fig.add_subplot(gs[0, 3])]
    z_plot = np.clip(z, 1e-3, None)
    contour_levels = [10**-2.5, 10**-2.0, 10**-1.5, 10**-1.0, 10**-0.5]
    label_fmt = {
        10**-2.5: r"$10^{-2.5}$",
        10**-2.0: r"$10^{-2}$",
        10**-1.5: r"$10^{-1.5}$",
        10**-1.0: r"$10^{-1}$",
        10**-0.5: r"$10^{-0.5}$",
    }
    for ax, cax, values, title in (
        (axes[0], cbar_axes[0], z_plot, "Relative RMS error"),
        (axes[1], cbar_axes[1], np.clip(boundary_approach, 1e-3, None), "Boundary approach index"),
    ):
        mesh = ax.pcolormesh(
            wtau_values,
            eps_values,
            values,
            shading="auto",
            cmap="magma",
            norm=LogNorm(vmin=1e-3, vmax=1.0),
            linewidth=0,
            edgecolors="none",
            antialiased=False,
        )
        cs = ax.contour(wtau_values, eps_values, values, levels=contour_levels, colors="white", linewidths=1.0)
        labels = ax.clabel(cs, fmt=label_fmt, fontsize=7, inline=False)
        for txt in labels:
            txt.set_rotation(0)
            txt.set_color("white")
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel(r"Normalized frequency, $\omega\tau$")
        if ax is axes[0]:
            ax.set_ylabel(r"Excursion, $\epsilon_{\mathrm{C}}$")
        else:
            ax.set_ylabel("")
        cbar = fig.colorbar(mesh, cax=cax, label=title)
        cbar.solids.set_edgecolor("face")
        style_colorbar(cbar)
        cbar.ax.yaxis.set_label_position("left")
        cbar.ax.yaxis.label.set_rotation(90)
        cbar.ax.yaxis.labelpad = 4

    examples = data["example_rows"]
    names = list(data["example_label_names"])
    colors = {0: PALETTE["blue"], 1: PALETTE["orange"], 2: PALETTE["red"]}
    for label_id in (0, 1, 2):
        pts = examples[examples[:, 0] == label_id]
        axes[2].plot(pts[:, 3], pts[:, 4], color=colors[label_id], lw=1.4)
        axes[2].plot(pts[:, 3], pts[:, 5], color=colors[label_id], lw=1.0, ls="--")
    axes[2].set_xlabel("Cycles")
    axes[2].set_ylabel("Complex concentration")
    axes[2].set_xlim(0.0, 2.0)
    axes[2].set_ylim(0.0, 1.5)
    regime_handles = [
        Line2D([0], [0], color=colors[label_id], lw=2.0, label=str(names[label_id]).title())
        for label_id in (0, 1, 2)
    ]
    style_handles = [
        Line2D([0], [0], color="0.15", lw=1.8, label="Full"),
        Line2D([0], [0], color="0.15", lw=1.4, ls="--", label="Local"),
    ]
    legend_regime = axes[2].legend(handles=regime_handles, frameon=False, loc="upper left")
    axes[2].add_artist(legend_regime)
    axes[2].legend(handles=style_handles, frameon=False, loc="upper right", handlelength=2.2)

    for ax in axes:
        ax.xaxis.labelpad = 2
        ax.yaxis.labelpad = 1
    finish_axes(axes, labels=["(a)", "(b)", "(c)"])
    save(fig, "Fig6")


PLOTTERS = {
    "1": plot_figure1,
    "2": plot_figure2,
    "3": plot_figure3,
    "4": plot_figure4,
    "5": plot_figure5,
    "6": plot_figure6,
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--figures",
        nargs="*",
        choices=sorted(PLOTTERS),
        default=sorted(PLOTTERS),
        help="figure numbers to plot; default plots all main figures",
    )
    args = parser.parse_args()

    ensure_dirs()
    apply_style()
    for figure_id in args.figures:
        plotter = PLOTTERS[figure_id]
        print(f"[plot] {plotter.__name__}", flush=True)
        plotter()
    print(f"[plot] wrote figures to {OUT_DIR}", flush=True)


if __name__ == "__main__":
    main()
