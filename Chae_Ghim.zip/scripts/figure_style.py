import matplotlib.pyplot as plt
import numpy as np


PALETTE = {
    "blue": "#1f77b4",
    "orange": "#ff7f0e",
    "green": "#2ca02c",
    "red": "#d62728",
    "purple": "#9467bd",
    "brown": "#8c564b",
    "cyan": "#17becf",
    "gray": "#4d4d4d",
}


def apply_style():
    plt.rcParams.update({
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "font.family": "Arial",
        "font.size": 7,
        "axes.labelsize": 7,
        "xtick.labelsize": 6,
        "ytick.labelsize": 6,
        "legend.fontsize": 6,
        "axes.linewidth": 0.9,
        "lines.linewidth": 1.2,
        "xtick.major.width": 0.85,
        "ytick.major.width": 0.85,
        "xtick.major.size": 3.1,
        "ytick.major.size": 3.1,
        "xtick.minor.width": 0.65,
        "ytick.minor.width": 0.65,
        "xtick.minor.size": 1.9,
        "ytick.minor.size": 1.9,
        "savefig.facecolor": "white",
        "savefig.edgecolor": "white",
    })


def style_axes(ax):
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(0.9)
        spine.set_color("black")
    ax.tick_params(direction="in", width=0.85, length=3.1, color="black")
    ax.tick_params(which="minor", direction="in", width=0.65, length=1.9, color="black")
    ax.grid(False)


def style_colorbar(cbar):
    cbar.outline.set_linewidth(0.8)
    cbar.ax.tick_params(direction="in", width=0.75, length=2.8, labelsize=6)
    cbar.ax.yaxis.label.set_size(7)


def panel_label(ax, label):
    ax.text(
        -0.16,
        1.08,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=8,
        fontweight="bold",
    )


def finish_axes(axes, labels=None):
    axes_array = np.asarray(axes, dtype=object).ravel()
    for idx, ax in enumerate(axes_array):
        style_axes(ax)
        if labels is not None:
            panel_label(ax, labels[idx])
